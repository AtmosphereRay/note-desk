import { ipcMain, dialog, BrowserWindow } from 'electron';
import { app } from 'electron';
import * as fs from 'fs/promises';
import * as path from 'path';
import { DEFAULT_SETTINGS, IPC_CHANNELS } from '../../shared/constants';
import type { AppSettings } from '../../shared/types';

let settings: AppSettings = { ...DEFAULT_SETTINGS };
const settingsPath = path.join(app.getPath('userData'), 'settings.json');

async function loadSettings(): Promise<AppSettings> {
  try {
    const data = await fs.readFile(settingsPath, 'utf-8');
    return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

async function saveSettings(newSettings: AppSettings): Promise<void> {
  try {
    await fs.writeFile(settingsPath, JSON.stringify(newSettings, null, 2), 'utf-8');
  } catch (error) {
    console.error('Failed to save settings:', error);
  }
}

export async function setupSettingsIPC(): Promise<void> {
  settings = await loadSettings();

  ipcMain.handle(IPC_CHANNELS.SETTINGS_GET, () => {
    return settings;
  });

  ipcMain.handle(IPC_CHANNELS.SETTINGS_UPDATE, async (_, updates: Partial<AppSettings>) => {
    settings = { ...settings, ...updates };
    await saveSettings(settings);
  });

  ipcMain.handle(IPC_CHANNELS.SETTINGS_SELECT_FOLDER, async (_, defaultPath?: string) => {
    const mainWindow = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
    if (!mainWindow) {
      throw new Error('No window available');
    }

    // 根据当前设置的语言选择对话框标题
    const currentLanguage = settings.general?.language || 'zh';
    const dialogTitle = currentLanguage === 'zh' ? '选择文件夹' : 'Select Folder';

    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory'],
      defaultPath: defaultPath || app.getPath('home'),
      title: dialogTitle
    });

    if (result.canceled) {
      return null;
    }

    return result.filePaths[0] || null;
  });
}

