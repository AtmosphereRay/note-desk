import { ipcMain } from 'electron';
import { SystemManager } from '../classes/SystemManager';
import { IPC_CHANNELS } from '../../shared/constants';

export function setupSystemIPC(systemManager: SystemManager): void {
  ipcMain.handle(IPC_CHANNELS.SYSTEM_GET_INFO, () => {
    return systemManager.getSystemInfo();
  });

  ipcMain.handle(IPC_CHANNELS.SYSTEM_SET_AUTO_LAUNCH, async (_, enable: boolean) => {
    await systemManager.setAutoLaunch(enable);
  });

  ipcMain.handle(IPC_CHANNELS.SYSTEM_SEND_NOTIFICATION, (_, options) => {
    systemManager.sendSystemNotification(options);
  });

  ipcMain.handle(IPC_CHANNELS.SYSTEM_SET_PROXY, (_, config) => {
    systemManager.setProxyConfig(config);
  });
}

