import { ipcMain } from 'electron';
import { LogManager } from '../classes/LogManager';
import { IPC_CHANNELS } from '../../shared/constants';

export function setupLogIPC(logManager: LogManager): void {
  ipcMain.handle(IPC_CHANNELS.LOG_GET_LIST, async (_, dateRange?) => {
    return await logManager.getLogList(dateRange);
  });

  ipcMain.handle(IPC_CHANNELS.LOG_CLEAN, async (_, days: number) => {
    await logManager.cleanLogs(days);
  });

  ipcMain.handle(IPC_CHANNELS.LOG_EXPORT, async (_, exportPath: string) => {
    // TODO: 实现日志导出逻辑
  });
}

