import { ipcMain, Menu, BrowserWindow } from 'electron';
import { randomUUID } from 'crypto';
import type { VideoApp } from '../../shared/types';
import { IPC_CHANNELS } from '../../shared/constants';
import * as fs from 'fs/promises';
import * as path from 'path';
import { app } from 'electron';
import { DEFAULT_SETTINGS } from '../../shared/constants';
import type { AppSettings } from '../../shared/types';

// 简单的内存存储
const videoApps: Map<string, VideoApp> = new Map();

// 翻译映射
const translations = {
  zh: {
    disable: '禁用',
    enable: '启用',
    startCrawl: '开启爬取'
  },
  en: {
    disable: 'Disable',
    enable: 'Enable',
    startCrawl: 'Start Crawling'
  }
};

// 获取当前语言设置
async function getCurrentLanguage(): Promise<'zh' | 'en'> {
  try {
    const settingsPath = path.join(app.getPath('userData'), 'settings.json');
    const data = await fs.readFile(settingsPath, 'utf-8');
    const settings: AppSettings = { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    return (settings.general?.language || 'zh') as 'zh' | 'en';
  } catch {
    return 'zh';
  }
}

export function setupVideoAppIPC(): void {
  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_ADD, (_, app) => {
    const id = randomUUID();
    const newApp: VideoApp = {
      id,
      ...app,
      status: 'normal',
      enabled: app.enabled !== false
    };
    videoApps.set(id, newApp);
    return id;
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_UPDATE, (_, id: string, updates: Partial<VideoApp>) => {
    const app = videoApps.get(id);
    if (app) {
      Object.assign(app, updates);
    }
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_DELETE, (_, id: string) => {
    videoApps.delete(id);
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_GET_LIST, () => {
    return Array.from(videoApps.values());
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_CHECK_SOURCES, async (_, appId: string) => {
    // TODO: 实现视频源检测逻辑
    const app = videoApps.get(appId);
    if (app) {
      // 检测逻辑
    }
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_SHOW_CONTEXT_MENU, async (event, options: { appId: string; enabled: boolean; x: number; y: number }) => {
    const { appId, enabled, x, y } = options;
    const mainWindow = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
    
    if (!mainWindow) {
      return;
    }

    // 获取当前语言设置
    const currentLang = await getCurrentLanguage();
    const t = translations[currentLang];

    const template = [
      {
        label: enabled ? t.disable : t.enable,
        click: async () => {
          const newEnabledState = !enabled;
          await toggleAppEnabled(appId);
          // 通知渲染进程更新IndexedDB并刷新列表
          mainWindow.webContents.send('video-app:enabled-changed', { 
            appId, 
            enabled: newEnabledState 
          });
        }
      },
      {
        label: t.startCrawl,
        click: async () => {
          await startCrawl(appId);
        }
      }
    ];

    const menu = Menu.buildFromTemplate(template);
    menu.popup({ window: mainWindow, x, y });
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_TOGGLE_ENABLED, async (_, appId: string) => {
    await toggleAppEnabled(appId);
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_APP_START_CRAWL, async (_, appId: string) => {
    await startCrawl(appId);
  });
}

async function toggleAppEnabled(appId: string): Promise<void> {
  const app = videoApps.get(appId);
  if (app) {
    app.enabled = !app.enabled;
    // 主进程存储同步（IndexedDB由渲染进程管理）
  }
}

async function startCrawl(appId: string): Promise<void> {
  const app = videoApps.get(appId);
  if (app && app.crawlerLogic) {
    // TODO: 实现爬取逻辑
    console.log('Starting crawl for app:', appId);
    // 这里可以执行app.crawlerLogic中的JavaScript代码
  }
}

