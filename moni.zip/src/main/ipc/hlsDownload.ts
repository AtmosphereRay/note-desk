import { ipcMain } from 'electron';
import { HlsDownloadManager } from '../classes/HlsDownloadManager';
import { IPC_CHANNELS } from '../../shared/constants';

export function setupHlsDownloadIPC(hlsDownloadManager: HlsDownloadManager): void {
  ipcMain.handle(IPC_CHANNELS.HLS_PARSE_M3U8, async (_, url: string) => {
    return await hlsDownloadManager.parseM3u8(url);
  });

  ipcMain.handle(IPC_CHANNELS.HLS_CREATE_DOWNLOAD, (_, task) => {
    return hlsDownloadManager.createDownloadTask(task);
  });

  ipcMain.handle(IPC_CHANNELS.HLS_OPERATE_TASK, async (_, taskId: string, action: 'pause' | 'resume' | 'cancel') => {
    await hlsDownloadManager.operateTask(taskId, action);
  });

  ipcMain.handle(IPC_CHANNELS.HLS_GET_TASKS, () => {
    return hlsDownloadManager.getTasks();
  });

  ipcMain.handle(IPC_CHANNELS.HLS_GET_PROGRESS, (_, taskId: string) => {
    return hlsDownloadManager.getProgress(taskId);
  });

  ipcMain.handle(IPC_CHANNELS.HLS_MERGE_TS, async (_, taskId: string) => {
    await hlsDownloadManager.mergeTsFiles(taskId);
  });
}

