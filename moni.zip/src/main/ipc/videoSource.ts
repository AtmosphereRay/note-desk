import { ipcMain } from 'electron';
import { randomUUID } from 'crypto';
import type { VideoSource } from '../../shared/types';
import { IPC_CHANNELS } from '../../shared/constants';

// 简单的内存存储，实际应该使用数据库或文件存储
const videoSources: Map<string, VideoSource> = new Map();

export function setupVideoSourceIPC(): void {
  ipcMain.handle(IPC_CHANNELS.VIDEO_SOURCE_ADD, (_, source) => {
    const id = randomUUID();
    const newSource: VideoSource = {
      id,
      ...source,
      updatedAt: new Date(),
      status: 'loading',
      enabled: source.enabled !== false
    };
    videoSources.set(id, newSource);
    return id;
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_SOURCE_UPDATE, (_, id: string, updates: Partial<VideoSource>) => {
    const source = videoSources.get(id);
    if (source) {
      Object.assign(source, updates);
      source.updatedAt = new Date();
    }
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_SOURCE_DELETE, (_, id: string) => {
    videoSources.delete(id);
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_SOURCE_GET_LIST, () => {
    return Array.from(videoSources.values());
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_SOURCE_IMPORT, (_, data: string, format: 'json' | 'txt') => {
    // TODO: 实现导入逻辑
  });

  ipcMain.handle(IPC_CHANNELS.VIDEO_SOURCE_EXPORT, (_, format: 'json' | 'txt') => {
    // TODO: 实现导出逻辑
    return JSON.stringify(Array.from(videoSources.values()));
  });
}

