import { ipcMain } from 'electron';
import { UpdateManager } from '../classes/UpdateManager';
import { IPC_CHANNELS } from '../../shared/constants';

export function setupUpdateIPC(updateManager: UpdateManager): void {
  ipcMain.handle(IPC_CHANNELS.UPDATE_CHECK, async () => {
    return await updateManager.checkForUpdates();
  });

  ipcMain.handle(IPC_CHANNELS.UPDATE_DOWNLOAD, async () => {
    await updateManager.downloadUpdate();
  });

  ipcMain.handle(IPC_CHANNELS.UPDATE_INSTALL, async () => {
    await updateManager.installUpdate();
  });

  ipcMain.handle(IPC_CHANNELS.UPDATE_GET_LOG, async (_, version: string) => {
    return await updateManager.getUpdateLog(version);
  });
}

