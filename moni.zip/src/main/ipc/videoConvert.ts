import { ipcMain } from 'electron';
import { VideoConvertManager } from '../classes/VideoConvertManager';
import { IPC_CHANNELS } from '../../shared/constants';

export function setupVideoConvertIPC(videoConvertManager: VideoConvertManager): void {
  ipcMain.handle(IPC_CHANNELS.CONVERT_CREATE_TASK, (_, task) => {
    return videoConvertManager.createConvertTask(task);
  });

  ipcMain.handle(IPC_CHANNELS.CONVERT_OPERATE_TASK, async (_, taskId: string, action: 'pause' | 'resume' | 'cancel') => {
    await videoConvertManager.operateTask(taskId, action);
  });

  ipcMain.handle(IPC_CHANNELS.CONVERT_GET_TASKS, () => {
    return videoConvertManager.getTasks();
  });

  ipcMain.handle(IPC_CHANNELS.CONVERT_GET_PROGRESS, (_, taskId: string) => {
    return videoConvertManager.getProgress(taskId);
  });
}

