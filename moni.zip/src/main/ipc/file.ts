import { ipcMain } from 'electron';
import { FileManager } from '../classes/FileManager';
import { IPC_CHANNELS } from '../../shared/constants';

export function setupFileIPC(fileManager: FileManager): void {
  ipcMain.handle(IPC_CHANNELS.FILE_SCAN_FOLDER, async (_, path: string, filter?: string[]) => {
    return await fileManager.scanFolder(path, filter);
  });

  ipcMain.handle(IPC_CHANNELS.FILE_MERGE_FILES, async (_, inputPaths: string[], outputPath: string) => {
    await fileManager.mergeFiles(inputPaths, outputPath);
  });

  ipcMain.handle(IPC_CHANNELS.FILE_GET_INFO, async (_, path: string) => {
    return await fileManager.getFileInfo(path);
  });

  ipcMain.handle(IPC_CHANNELS.FILE_DELETE, async (_, path: string) => {
    await fileManager.safeDeleteFile(path);
  });

  ipcMain.handle(IPC_CHANNELS.FILE_RENAME, async (_, oldPath: string, newPath: string) => {
    await fileManager.renameFile(oldPath, newPath);
  });
}

