import { ipcMain, BrowserWindow } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import { ProcessManager } from '../classes/ProcessManager';

let processManager: ProcessManager | null = null;
let isQuitting = false;

export function setupAppIPC(manager: ProcessManager): void {
  processManager = manager;

  ipcMain.handle(IPC_CHANNELS.APP_QUIT_CONFIRM, async () => {
    if (!processManager) {
      return;
    }

    try {
      // 尝试优雅关闭所有进程
      await processManager.killAllProcesses();
    } catch (error) {
      console.error('Failed to kill processes gracefully, forcing kill:', error);
      // 如果优雅关闭失败，强制关闭
      try {
        await processManager.forceKillAllProcesses();
      } catch (forceError) {
        console.error('Failed to force kill processes:', forceError);
      }
    }

    // 标记正在退出
    isQuitting = true;
    
    // 退出应用
    const windows = BrowserWindow.getAllWindows();
    windows.forEach(window => {
      window.destroy();
    });
    
    // 给一点时间让窗口关闭
    setTimeout(() => {
      process.exit(0);
    }, 100);
  });

  ipcMain.handle(IPC_CHANNELS.APP_QUIT_CANCEL, () => {
    // 取消退出，不做任何处理
    isQuitting = false;
  });
}

export function getIsQuitting(): boolean {
  return isQuitting;
}

