import { BrowserWindow, screen } from 'electron';
import * as path from 'path';
import type { WindowOptions } from '../../shared/types';

interface WindowState {
  x?: number;
  y?: number;
  width: number;
  height: number;
}

export class WindowManager {
  private windows: Map<string, BrowserWindow> = new Map();
  private windowStates: Map<string, WindowState> = new Map();

  createWindow(options: WindowOptions): BrowserWindow {
    const savedState = this.windowStates.get(options.name);
    const display = screen.getPrimaryDisplay();
    const { width: screenWidth, height: screenHeight } = display.workAreaSize;

    const defaultWidth = options.width || 1200;
    const defaultHeight = options.height || 800;

    const window = new BrowserWindow({
      width: savedState?.width || defaultWidth,
      height: savedState?.height || defaultHeight,
      x: savedState?.x || Math.floor((screenWidth - defaultWidth) / 2),
      y: savedState?.y || Math.floor((screenHeight - defaultHeight) / 2),
      minWidth: options.minWidth,
      minHeight: options.minHeight,
      resizable: options.resizable !== false,
      frame: options.frame !== false,
      transparent: options.transparent || false,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        preload: options.webPreferences?.preload || path.join(__dirname, '../preload/index.js'),
        ...options.webPreferences
      }
    });

    // 保存窗口状态
    window.on('moved', () => this.saveWindowState(options.name, window));
    window.on('resized', () => this.saveWindowState(options.name, window));
    window.on('close', () => {
      this.saveWindowState(options.name, window);
      this.windows.delete(options.name);
    });

    this.windows.set(options.name, window);
    return window;
  }

  getWindow(name: string): BrowserWindow | undefined {
    return this.windows.get(name);
  }

  switchWindow(name: string): void {
    const window = this.windows.get(name);
    if (window) {
      if (window.isMinimized()) {
        window.restore();
      }
      window.focus();
    }
  }

  resizeWindow(name: string, size: { width: number; height: number }): void {
    const window = this.windows.get(name);
    if (window) {
      window.setSize(size.width, size.height);
    }
  }

  private saveWindowState(name: string, window: BrowserWindow): void {
    const bounds = window.getBounds();
    this.windowStates.set(name, {
      x: bounds.x,
      y: bounds.y,
      width: bounds.width,
      height: bounds.height
    });
  }

  restoreWindowState(name: string): WindowState | undefined {
    return this.windowStates.get(name);
  }

  closeWindow(name: string): void {
    const window = this.windows.get(name);
    if (window) {
      window.close();
    }
  }

  closeAllWindows(): void {
    this.windows.forEach((window) => window.close());
    this.windows.clear();
  }
}

