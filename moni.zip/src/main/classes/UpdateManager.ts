import { autoUpdater } from 'electron-updater';
import type { UpdateInfo } from '../../shared/types';

export class UpdateManager {
  constructor() {
    autoUpdater.autoDownload = false;
    autoUpdater.autoInstallOnAppQuit = true;
  }

  async checkForUpdates(): Promise<UpdateInfo | null> {
    try {
      const result = await autoUpdater.checkForUpdates();
      if (result && result.updateInfo) {
        const releaseNotes = result.updateInfo.releaseNotes;
        const releaseNotesStr = Array.isArray(releaseNotes) 
          ? releaseNotes.map(note => typeof note === 'string' ? note : note.note || '').join('\n')
          : (typeof releaseNotes === 'string' ? releaseNotes : '');
        
        return {
          version: result.updateInfo.version,
          releaseDate: result.updateInfo.releaseDate || new Date().toISOString(),
          releaseNotes: releaseNotesStr,
          downloadUrl: '',
          sha256: '',
          size: 0
        };
      }
      return null;
    } catch (error) {
      console.error('Failed to check for updates:', error);
      return null;
    }
  }

  async downloadUpdate(): Promise<void> {
    await autoUpdater.downloadUpdate();
  }

  async installUpdate(): Promise<void> {
    autoUpdater.quitAndInstall();
  }

  async getUpdateLog(version: string): Promise<string> {
    // TODO: 从更新服务器获取更新日志
    return '';
  }

  handleUpdateError(error: Error): void {
    console.error('Update error:', error);
  }
}

