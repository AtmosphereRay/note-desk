import { spawn, ChildProcess, exec } from 'child_process';
import { promisify } from 'util';
import * as os from 'os';
import type { HlsDownloadTask, VideoConvertTask } from '../../shared/types';

const execAsync = promisify(exec);

export class ProcessManager {
  private processes: Map<string, ChildProcess> = new Map();

  spawnHlsDownloadProcess(taskId: string, config: any): ChildProcess {
    // TODO: 实现 HLS 下载子进程
    const process = spawn('node', ['--version']);
    this.processes.set(taskId, process);
    return process;
  }

  spawnVideoConvertProcess(taskId: string, config: any): ChildProcess {
    // TODO: 实现视频转换子进程（使用 ffmpeg）
    const process = spawn('ffmpeg', []);
    this.processes.set(taskId, process);
    return process;
  }

  spawnThirdPartyService(serviceName: string, config: any): ChildProcess {
    // TODO: 实现第三方服务进程
    const process = spawn('node', []);
    this.processes.set(serviceName, process);
    return process;
  }

  killProcess(pid: number): void {
    try {
      process.kill(pid);
    } catch (error) {
      console.error(`Failed to kill process ${pid}:`, error);
    }
  }

  monitorProcess(pid: number): void {
    // TODO: 实现进程监控逻辑
  }

  /**
   * 获取所有子进程的 PID 列表
   */
  getAllProcessPids(): number[] {
    const pids: number[] = [];
    this.processes.forEach((proc) => {
      if (proc.pid) {
        pids.push(proc.pid);
      }
    });
    return pids;
  }

  /**
   * 优雅关闭所有进程
   */
  async killAllProcesses(): Promise<void> {
    const promises: Promise<void>[] = [];
    
    this.processes.forEach((proc, key) => {
      if (proc.pid && !proc.killed) {
        promises.push(
          new Promise<void>((resolve) => {
            try {
              proc.kill('SIGTERM');
              // 等待进程退出，最多等待 3 秒
              const timeout = setTimeout(() => {
                if (!proc.killed && proc.pid) {
                  // 超时后强制关闭
                  this.forceKillProcess(proc.pid).finally(() => resolve());
                } else {
                  resolve();
                }
              }, 3000);

              proc.once('exit', () => {
                clearTimeout(timeout);
                resolve();
              });

              proc.once('error', () => {
                clearTimeout(timeout);
                if (proc.pid) {
                  this.forceKillProcess(proc.pid).finally(() => resolve());
                } else {
                  resolve();
                }
              });
            } catch (error) {
              console.error(`Failed to kill process ${key}:`, error);
              if (proc.pid) {
                this.forceKillProcess(proc.pid).finally(() => resolve());
              } else {
                resolve();
              }
            }
          })
        );
      }
    });

    await Promise.all(promises);
    this.processes.clear();
  }

  /**
   * 强制关闭进程（使用系统命令）
   */
  async forceKillProcess(pid: number): Promise<void> {
    const platform = os.platform();
    
    try {
      if (platform === 'win32') {
        // Windows: 使用 taskkill
        await execAsync(`taskkill /F /PID ${pid}`, { timeout: 5000 });
      } else if (platform === 'darwin' || platform === 'linux') {
        // macOS/Linux: 使用 kill -9
        await execAsync(`kill -9 ${pid}`, { timeout: 5000 });
      } else {
        // 其他平台：尝试使用 kill
        await execAsync(`kill -9 ${pid}`, { timeout: 5000 });
      }
    } catch (error) {
      console.error(`Failed to force kill process ${pid}:`, error);
      throw error;
    }
  }

  /**
   * 强制关闭所有进程
   */
  async forceKillAllProcesses(): Promise<void> {
    const pids = this.getAllProcessPids();
    const promises = pids.map(pid => this.forceKillProcess(pid).catch(err => {
      console.error(`Failed to force kill process ${pid}:`, err);
    }));
    
    await Promise.all(promises);
    this.processes.clear();
  }
}

