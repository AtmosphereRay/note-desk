import { randomUUID } from 'crypto';
import type { VideoConvertTask } from '../../shared/types';

export class VideoConvertManager {
  private tasks: Map<string, VideoConvertTask> = new Map();

  createConvertTask(task: Omit<VideoConvertTask, 'id' | 'status' | 'progress'>): string {
    const id = randomUUID();
    const newTask: VideoConvertTask = {
      id,
      ...task,
      status: 'waiting',
      progress: 0
    };
    this.tasks.set(id, newTask);
    return id;
  }

  async operateTask(taskId: string, action: 'pause' | 'resume' | 'cancel'): Promise<void> {
    const task = this.tasks.get(taskId);
    if (!task) {
      throw new Error(`Task ${taskId} not found`);
    }

    switch (action) {
      case 'pause':
        task.status = 'paused';
        break;
      case 'resume':
        task.status = 'converting';
        break;
      case 'cancel':
        task.status = 'cancelled';
        this.tasks.delete(taskId);
        break;
    }
  }

  getTasks(): VideoConvertTask[] {
    return Array.from(this.tasks.values());
  }

  getProgress(taskId: string): VideoConvertTask | undefined {
    return this.tasks.get(taskId);
  }
}

