import * as fs from 'fs/promises';
import * as path from 'path';
import { app } from 'electron';
import { randomUUID } from 'crypto';
import type { LogEntry } from '../../shared/types';

export class LogManager {
  private logDir: string;
  private logs: LogEntry[] = [];

  constructor() {
    this.logDir = path.join(app.getPath('userData'), 'logs');
    this.ensureLogDir();
  }

  private async ensureLogDir(): Promise<void> {
    try {
      await fs.mkdir(this.logDir, { recursive: true });
    } catch (error) {
      console.error('Failed to create log directory:', error);
    }
  }

  private async writeToFile(entry: LogEntry): Promise<void> {
    const date = new Date();
    const dateStr = date.toISOString().split('T')[0];
    const logFile = path.join(this.logDir, `app-${dateStr}.log`);
    
    const logLine = `[${entry.timestamp.toISOString()}] [${entry.level.toUpperCase()}] [${entry.module}] ${entry.message}${entry.error ? '\n' + entry.error.stack : ''}\n`;
    
    try {
      await fs.appendFile(logFile, logLine, 'utf-8');
    } catch (error) {
      console.error('Failed to write log:', error);
    }
  }

  debug(module: string, message: string, meta?: any): void {
    const entry: LogEntry = {
      id: randomUUID(),
      level: 'debug',
      module,
      message,
      timestamp: new Date(),
      meta
    };
    this.logs.push(entry);
    this.writeToFile(entry);
  }

  info(module: string, message: string, meta?: any): void {
    const entry: LogEntry = {
      id: randomUUID(),
      level: 'info',
      module,
      message,
      timestamp: new Date(),
      meta
    };
    this.logs.push(entry);
    this.writeToFile(entry);
  }

  warn(module: string, message: string, meta?: any): void {
    const entry: LogEntry = {
      id: randomUUID(),
      level: 'warn',
      module,
      message,
      timestamp: new Date(),
      meta
    };
    this.logs.push(entry);
    this.writeToFile(entry);
  }

  error(module: string, message: string, error?: Error, meta?: any): void {
    const entry: LogEntry = {
      id: randomUUID(),
      level: 'error',
      module,
      message,
      timestamp: new Date(),
      error,
      meta
    };
    this.logs.push(entry);
    this.writeToFile(entry);
  }

  async getLogList(dateRange?: { start: Date; end: Date }): Promise<LogEntry[]> {
    if (!dateRange) {
      return [...this.logs];
    }

    return this.logs.filter(log => {
      return log.timestamp >= dateRange.start && log.timestamp <= dateRange.end;
    });
  }

  async cleanLogs(days: number): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    // 清理内存中的日志
    this.logs = this.logs.filter(log => log.timestamp >= cutoffDate);

    // 清理文件中的旧日志
    try {
      const files = await fs.readdir(this.logDir);
      for (const file of files) {
        if (file.startsWith('app-') && file.endsWith('.log')) {
          const filePath = path.join(this.logDir, file);
          const stats = await fs.stat(filePath);
          if (stats.mtime < cutoffDate) {
            await fs.unlink(filePath);
          }
        }
      }
    } catch (error) {
      console.error('Failed to clean log files:', error);
    }
  }
}

