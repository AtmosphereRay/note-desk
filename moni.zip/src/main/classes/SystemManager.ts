import { app, Notification } from 'electron';
import * as os from 'os';
import type { SystemInfo, NotificationOptions, ProxyConfig } from '../../shared/types';

export class SystemManager {
  getSystemInfo(): SystemInfo {
    return {
      platform: process.platform as 'win32' | 'darwin' | 'linux',
      version: os.release(),
      arch: os.arch(),
      totalMemory: os.totalmem(),
      freeMemory: os.freemem()
    };
  }

  async setAutoLaunch(enable: boolean): Promise<void> {
    try {
      const AutoLaunch = require('auto-launch');
      const autoLauncher = new AutoLaunch({
        name: 'HLS Video Manager',
        path: app.getPath('exe')
      });

      if (enable) {
        await autoLauncher.enable();
      } else {
        await autoLauncher.disable();
      }
    } catch (error) {
      console.error('Failed to set auto launch:', error);
    }
  }

  sendSystemNotification(options: NotificationOptions): void {
    if (Notification.isSupported()) {
      const notification = new Notification({
        title: options.title,
        body: options.body,
        icon: options.icon
      });
      notification.show();
    }
  }

  setProxyConfig(config: ProxyConfig): void {
    const proxyUrl = config.username && config.password
      ? `${config.protocol || 'http'}://${config.username}:${config.password}@${config.host}:${config.port}`
      : `${config.protocol || 'http'}://${config.host}:${config.port}`;
    
    app.commandLine.appendSwitch('proxy-server', proxyUrl);
  }
}

