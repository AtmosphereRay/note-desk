import * as fs from 'fs/promises';
import * as path from 'path';
import { statSync } from 'fs';
import type { FileInfo } from '../../shared/types';

export class FileManager {
  async scanFolder(folderPath: string, filter: string[] = []): Promise<FileInfo[]> {
    const files: FileInfo[] = [];
    
    try {
      const entries = await fs.readdir(folderPath, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(folderPath, entry.name);
        
        if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase().slice(1);
          if (filter.length === 0 || filter.includes(ext)) {
            const stats = statSync(fullPath);
            files.push({
              path: fullPath,
              name: entry.name,
              size: stats.size,
              type: ext,
              created: stats.birthtime,
              modified: stats.mtime
            });
          }
        } else if (entry.isDirectory()) {
          // 递归扫描子目录
          const subFiles = await this.scanFolder(fullPath, filter);
          files.push(...subFiles);
        }
      }
    } catch (error) {
      console.error(`Error scanning folder ${folderPath}:`, error);
    }
    
    return files;
  }

  async mergeFiles(inputPaths: string[], outputPath: string): Promise<void> {
    const writeStream = await fs.open(outputPath, 'w');
    
    try {
      for (const inputPath of inputPaths) {
        const data = await fs.readFile(inputPath);
        await writeStream.write(data);
      }
    } finally {
      await writeStream.close();
    }
  }

  async getFileInfo(filePath: string): Promise<FileInfo> {
    const stats = statSync(filePath);
    return {
      path: filePath,
      name: path.basename(filePath),
      size: stats.size,
      type: path.extname(filePath).toLowerCase().slice(1),
      created: stats.birthtime,
      modified: stats.mtime
    };
  }

  async safeDeleteFile(filePath: string): Promise<void> {
    await fs.unlink(filePath);
  }

  async renameFile(oldPath: string, newPath: string): Promise<void> {
    await fs.rename(oldPath, newPath);
  }
}

