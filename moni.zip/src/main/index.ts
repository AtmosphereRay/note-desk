import { app, BrowserWindow } from 'electron';
import * as path from 'path';
import { IPC_CHANNELS } from '../shared/constants';
import { SystemManager } from './classes/SystemManager';
import { FileManager } from './classes/FileManager';
import { WindowManager } from './classes/WindowManager';
import { LogManager } from './classes/LogManager';
import { HlsDownloadManager } from './classes/HlsDownloadManager';
import { VideoConvertManager } from './classes/VideoConvertManager';
import { ProcessManager } from './classes/ProcessManager';
import { UpdateManager } from './classes/UpdateManager';
import { setupSystemIPC } from './ipc/system';
import { setupFileIPC } from './ipc/file';
import { setupHlsDownloadIPC } from './ipc/hlsDownload';
import { setupVideoConvertIPC } from './ipc/videoConvert';
import { setupVideoSourceIPC } from './ipc/videoSource';
import { setupVideoAppIPC } from './ipc/videoApp';
import { setupSettingsIPC } from './ipc/settings';
import { setupLogIPC } from './ipc/log';
import { setupUpdateIPC } from './ipc/update';
import { setupAppIPC, getIsQuitting } from './ipc/app';

// 初始化管理器
const systemManager = new SystemManager();
const fileManager = new FileManager();
const windowManager = new WindowManager();
const logManager = new LogManager();
const hlsDownloadManager = new HlsDownloadManager();
const videoConvertManager = new VideoConvertManager();
const processManager = new ProcessManager();
const updateManager = new UpdateManager();

// 设置 IPC 处理器
setupSystemIPC(systemManager);
setupFileIPC(fileManager);
setupHlsDownloadIPC(hlsDownloadManager);
setupVideoConvertIPC(videoConvertManager);
setupVideoSourceIPC();
setupVideoAppIPC();
setupLogIPC(logManager);
setupUpdateIPC(updateManager);
setupAppIPC(processManager);

// 等待设置加载完成
app.whenReady().then(async () => {
  await setupSettingsIPC();

  // 创建主窗口
  const mainWindow = windowManager.createWindow({
    name: 'main',
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, '../preload/index.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  // 监听窗口关闭事件，显示退出确认
  mainWindow.on('close', (event) => {
    // 如果正在退出，允许关闭
    if (getIsQuitting()) {
      return;
    }

    // 阻止默认关闭行为
    event.preventDefault();

    // 通知渲染进程显示退出确认
    mainWindow.webContents.send(IPC_CHANNELS.APP_QUIT_REQUEST);
  });

  // 加载渲染进程
  if (process.env.NODE_ENV === 'development') {
    // 开发环境：使用 Vite 开发服务器
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    // 生产环境：加载构建后的文件
    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
  }

  // electron-vite 会自动处理热更新

  // 监听渲染进程崩溃
  mainWindow.webContents.on('render-process-gone', (event, killed) => {
    logManager.error('Renderer', 'Renderer process crashed', undefined, { killed });
    // TODO: 实现崩溃恢复逻辑
  });

  mainWindow.webContents.on('unresponsive', () => {
    logManager.warn('Renderer', 'Renderer process became unresponsive');
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      windowManager.createWindow({
        name: 'main',
        width: 1200,
        height: 800
      });
    }
  });
});

app.on('window-all-closed', () => {
  // 如果正在退出，不处理
  if (getIsQuitting()) {
    return;
  }
  
  if (process.platform !== 'darwin') {
    // 触发退出确认流程
    const mainWindow = BrowserWindow.getAllWindows()[0];
    if (mainWindow) {
      mainWindow.webContents.send(IPC_CHANNELS.APP_QUIT_REQUEST);
    }
  }
});

app.on('before-quit', (event) => {
  // 如果正在退出，允许退出
  if (getIsQuitting()) {
    return;
  }

  // 阻止默认退出行为
  event.preventDefault();

  // 触发退出确认流程
  const mainWindow = BrowserWindow.getAllWindows()[0];
  if (mainWindow) {
    mainWindow.webContents.send(IPC_CHANNELS.APP_QUIT_REQUEST);
  }
});

