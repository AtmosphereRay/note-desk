import { ipcRenderer } from 'electron';
import type { LogApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const logApi: LogApi = {
  getList: (dateRange?) => ipcRenderer.invoke(IPC_CHANNELS.LOG_GET_LIST, dateRange),
  clean: (days: number) => ipcRenderer.invoke(IPC_CHANNELS.LOG_CLEAN, days),
  export: (path: string) => ipcRenderer.invoke(IPC_CHANNELS.LOG_EXPORT, path)
};

