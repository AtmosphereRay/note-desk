import { ipcRenderer } from 'electron';
import type { UpdateApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const updateApi: UpdateApi = {
  checkForUpdates: () => ipcRenderer.invoke(IPC_CHANNELS.UPDATE_CHECK),
  downloadUpdate: () => ipcRenderer.invoke(IPC_CHANNELS.UPDATE_DOWNLOAD),
  installUpdate: () => ipcRenderer.invoke(IPC_CHANNELS.UPDATE_INSTALL),
  getUpdateLog: (version: string) => ipcRenderer.invoke(IPC_CHANNELS.UPDATE_GET_LOG, version)
};

