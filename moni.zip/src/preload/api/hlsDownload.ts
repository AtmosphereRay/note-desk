import { ipcRenderer } from 'electron';
import type { HlsDownloadApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const hlsDownloadApi: HlsDownloadApi = {
  parseM3u8: (url: string) => ipcRenderer.invoke(IPC_CHANNELS.HLS_PARSE_M3U8, url),
  createDownloadTask: (task) => ipcRenderer.invoke(IPC_CHANNELS.HLS_CREATE_DOWNLOAD, task),
  operateTask: (taskId: string, action: 'pause' | 'resume' | 'cancel') => 
    ipcRenderer.invoke(IPC_CHANNELS.HLS_OPERATE_TASK, taskId, action),
  getTasks: () => ipcRenderer.invoke(IPC_CHANNELS.HLS_GET_TASKS),
  getProgress: (taskId: string) => ipcRenderer.invoke(IPC_CHANNELS.HLS_GET_PROGRESS, taskId),
  mergeTsFiles: (taskId: string) => ipcRenderer.invoke(IPC_CHANNELS.HLS_MERGE_TS, taskId)
};

