import { ipcRenderer } from 'electron';
import type { VideoAppApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const videoAppApi: VideoAppApi = {
  add: (app) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_ADD, app),
  update: (id: string, updates) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_UPDATE, id, updates),
  delete: (id: string) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_DELETE, id),
  getList: () => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_GET_LIST),
  checkSources: (appId: string) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_CHECK_SOURCES, appId),
  showContextMenu: (options) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_SHOW_CONTEXT_MENU, options),
  toggleEnabled: (appId: string) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_TOGGLE_ENABLED, appId),
  startCrawl: (appId: string) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_APP_START_CRAWL, appId)
};

