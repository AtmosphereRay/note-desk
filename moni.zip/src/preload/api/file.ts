import { ipcRenderer } from 'electron';
import type { FileApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const fileApi: FileApi = {
  scanFolder: (path: string, filter?: string[]) => ipcRenderer.invoke(IPC_CHANNELS.FILE_SCAN_FOLDER, path, filter),
  mergeFiles: (inputPaths: string[], outputPath: string) => ipcRenderer.invoke(IPC_CHANNELS.FILE_MERGE_FILES, inputPaths, outputPath),
  getFileInfo: (path: string) => ipcRenderer.invoke(IPC_CHANNELS.FILE_GET_INFO, path),
  safeDeleteFile: (path: string) => ipcRenderer.invoke(IPC_CHANNELS.FILE_DELETE, path),
  renameFile: (oldPath: string, newPath: string) => ipcRenderer.invoke(IPC_CHANNELS.FILE_RENAME, oldPath, newPath)
};

