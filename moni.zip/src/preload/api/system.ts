import { contextBridge, ipcRenderer } from 'electron';
import type { SystemApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const systemApi: SystemApi = {
  getSystemInfo: () => ipcRenderer.invoke(IPC_CHANNELS.SYSTEM_GET_INFO),
  setAutoLaunch: (enable: boolean) => ipcRenderer.invoke(IPC_CHANNELS.SYSTEM_SET_AUTO_LAUNCH, enable),
  sendSystemNotification: (options) => ipcRenderer.invoke(IPC_CHANNELS.SYSTEM_SEND_NOTIFICATION, options),
  setProxyConfig: (config) => ipcRenderer.invoke(IPC_CHANNELS.SYSTEM_SET_PROXY, config)
};

