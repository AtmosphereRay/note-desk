import { ipcRenderer } from 'electron';
import type { AppApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const appApi: AppApi = {
  confirmQuit: () => ipcRenderer.invoke(IPC_CHANNELS.APP_QUIT_CONFIRM),
  cancelQuit: () => ipcRenderer.invoke(IPC_CHANNELS.APP_QUIT_CANCEL)
};

