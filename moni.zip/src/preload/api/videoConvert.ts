import { ipcRenderer } from 'electron';
import type { VideoConvertApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const videoConvertApi: VideoConvertApi = {
  createConvertTask: (task) => ipcRenderer.invoke(IPC_CHANNELS.CONVERT_CREATE_TASK, task),
  operateTask: (taskId: string, action: 'pause' | 'resume' | 'cancel') => 
    ipcRenderer.invoke(IPC_CHANNELS.CONVERT_OPERATE_TASK, taskId, action),
  getTasks: () => ipcRenderer.invoke(IPC_CHANNELS.CONVERT_GET_TASKS),
  getProgress: (taskId: string) => ipcRenderer.invoke(IPC_CHANNELS.CONVERT_GET_PROGRESS, taskId)
};

