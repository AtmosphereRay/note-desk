import { ipcRenderer } from 'electron';
import type { VideoSourceApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const videoSourceApi: VideoSourceApi = {
  add: (source) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_SOURCE_ADD, source),
  update: (id: string, updates) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_SOURCE_UPDATE, id, updates),
  delete: (id: string) => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_SOURCE_DELETE, id),
  getList: () => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_SOURCE_GET_LIST),
  import: (data: string, format: 'json' | 'txt') => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_SOURCE_IMPORT, data, format),
  export: (format: 'json' | 'txt') => ipcRenderer.invoke(IPC_CHANNELS.VIDEO_SOURCE_EXPORT, format)
};

