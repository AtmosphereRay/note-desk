import { ipcRenderer } from 'electron';
import type { SettingsApi } from '../types';
import { IPC_CHANNELS } from '../../shared/constants';

export const settingsApi: SettingsApi = {
  get: () => ipcRenderer.invoke(IPC_CHANNELS.SETTINGS_GET),
  update: (updates) => ipcRenderer.invoke(IPC_CHANNELS.SETTINGS_UPDATE, updates),
  selectFolder: (defaultPath?: string) => ipcRenderer.invoke(IPC_CHANNELS.SETTINGS_SELECT_FOLDER, defaultPath)
};

