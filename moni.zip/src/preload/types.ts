// Preload API 类型定义
import type { 
  SystemInfo, 
  NotificationOptions, 
  ProxyConfig,
  FileInfo,
  HlsDownloadTask,
  VideoConvertTask,
  VideoSource,
  VideoApp,
  AppSettings,
  LogEntry,
  UpdateInfo
} from '../shared/types';

export interface SystemApi {
  getSystemInfo(): Promise<SystemInfo>;
  setAutoLaunch(enable: boolean): Promise<void>;
  sendSystemNotification(options: NotificationOptions): Promise<void>;
  setProxyConfig(config: ProxyConfig): Promise<void>;
}

export interface FileApi {
  scanFolder(path: string, filter?: string[]): Promise<FileInfo[]>;
  mergeFiles(inputPaths: string[], outputPath: string): Promise<void>;
  getFileInfo(path: string): Promise<FileInfo>;
  safeDeleteFile(path: string): Promise<void>;
  renameFile(oldPath: string, newPath: string): Promise<void>;
}

export interface HlsDownloadApi {
  parseM3u8(url: string): Promise<any>;
  createDownloadTask(task: Omit<HlsDownloadTask, 'id' | 'status' | 'progress'>): Promise<string>;
  operateTask(taskId: string, action: 'pause' | 'resume' | 'cancel'): Promise<void>;
  getTasks(): Promise<HlsDownloadTask[]>;
  getProgress(taskId: string): Promise<HlsDownloadTask>;
  mergeTsFiles(taskId: string): Promise<void>;
}

export interface VideoConvertApi {
  createConvertTask(task: Omit<VideoConvertTask, 'id' | 'status' | 'progress'>): Promise<string>;
  operateTask(taskId: string, action: 'pause' | 'resume' | 'cancel'): Promise<void>;
  getTasks(): Promise<VideoConvertTask[]>;
  getProgress(taskId: string): Promise<VideoConvertTask>;
}

export interface VideoSourceApi {
  add(source: Omit<VideoSource, 'id' | 'updatedAt'>): Promise<string>;
  update(id: string, updates: Partial<VideoSource>): Promise<void>;
  delete(id: string): Promise<void>;
  getList(): Promise<VideoSource[]>;
  import(data: string, format: 'json' | 'txt'): Promise<void>;
  export(format: 'json' | 'txt'): Promise<string>;
}

export interface VideoAppApi {
  add(app: Omit<VideoApp, 'id' | 'status'>): Promise<string>;
  update(id: string, updates: Partial<VideoApp>): Promise<void>;
  delete(id: string): Promise<void>;
  getList(): Promise<VideoApp[]>;
  checkSources(appId: string): Promise<void>;
  showContextMenu(options: { appId: string; enabled: boolean; x: number; y: number }): Promise<void>;
  toggleEnabled(appId: string): Promise<void>;
  startCrawl(appId: string): Promise<void>;
}

export interface SettingsApi {
  get(): Promise<AppSettings>;
  update(updates: Partial<AppSettings>): Promise<void>;
  selectFolder(defaultPath?: string): Promise<string | null>;
}

export interface LogApi {
  getList(dateRange?: { start: Date; end: Date }): Promise<LogEntry[]>;
  clean(days: number): Promise<void>;
  export(path: string): Promise<void>;
}

export interface UpdateApi {
  checkForUpdates(): Promise<UpdateInfo | null>;
  downloadUpdate(): Promise<void>;
  installUpdate(): Promise<void>;
  getUpdateLog(version: string): Promise<string>;
}

export interface AppApi {
  confirmQuit(): Promise<void>;
  cancelQuit(): Promise<void>;
}

export interface ElectronApi {
  system: SystemApi;
  file: FileApi;
  hlsDownload: HlsDownloadApi;
  videoConvert: VideoConvertApi;
  videoSource: VideoSourceApi;
  videoApp: VideoAppApi;
  settings: SettingsApi;
  log: LogApi;
  update: UpdateApi;
  app: AppApi;
}

declare global {
  interface Window {
    electron: ElectronApi;
  }
}

