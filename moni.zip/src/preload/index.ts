import { contextBridge, ipcRenderer } from 'electron';
import { systemApi } from './api/system';
import { fileApi } from './api/file';
import { hlsDownloadApi } from './api/hlsDownload';
import { videoConvertApi } from './api/videoConvert';
import { videoSourceApi } from './api/videoSource';
import { videoAppApi } from './api/videoApp';
import { settingsApi } from './api/settings';
import { logApi } from './api/log';
import { updateApi } from './api/update';
import { appApi } from './api/app';
import type { ElectronApi } from './types';
import { IPC_CHANNELS } from '../shared/constants';

const electronApi: ElectronApi = {
  system: systemApi,
  file: fileApi,
  hlsDownload: hlsDownloadApi,
  videoConvert: videoConvertApi,
  videoSource: videoSourceApi,
  videoApp: videoAppApi,
  settings: settingsApi,
  log: logApi,
  update: updateApi,
  app: appApi
};

contextBridge.exposeInMainWorld('electron', electronApi);

// 暴露事件监听API
contextBridge.exposeInMainWorld('electronEvents', {
  onVideoAppRefreshList: (callback: () => void) => {
    ipcRenderer.on('video-app:refresh-list', callback);
    return () => {
      ipcRenderer.removeListener('video-app:refresh-list', callback);
    };
  },
  onVideoAppEnabledChanged: (callback: (event: any, data: { appId: string; enabled: boolean }) => void) => {
    ipcRenderer.on('video-app:enabled-changed', callback);
    return () => {
      ipcRenderer.removeListener('video-app:enabled-changed', callback);
    };
  },
  onAppQuitRequest: (callback: () => void) => {
    ipcRenderer.on(IPC_CHANNELS.APP_QUIT_REQUEST, callback);
    return () => {
      ipcRenderer.removeListener(IPC_CHANNELS.APP_QUIT_REQUEST, callback);
    };
  }
});

