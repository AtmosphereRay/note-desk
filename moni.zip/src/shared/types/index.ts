// 共享类型定义

export interface SystemInfo {
  platform: 'win32' | 'darwin' | 'linux';
  version: string;
  arch: string;
  totalMemory: number;
  freeMemory: number;
}

export interface NotificationOptions {
  title: string;
  body: string;
  icon?: string;
}

export interface ProxyConfig {
  host: string;
  port: number;
  protocol?: 'http' | 'https' | 'socks4' | 'socks5';
  username?: string;
  password?: string;
}

export interface FileInfo {
  path: string;
  name: string;
  size: number;
  type: string;
  created: Date;
  modified: Date;
}

export interface HlsDownloadTask {
  id: string;
  name: string;
  url: string;
  outputPath: string;
  resolution?: string;
  downloadSubtitles?: boolean;
  concurrency?: number;
  priority?: 'high' | 'medium' | 'low';
  status: 'pending' | 'downloading' | 'paused' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  downloadedSize: number;
  totalSize: number;
  speed: number;
  remainingTime: number;
  currentSegment: number;
  totalSegments: number;
}

export interface VideoConvertTask {
  id: string;
  name: string;
  inputPath: string;
  outputPath: string;
  format: 'mp4' | 'mkv' | 'avi' | 'wmv';
  resolution?: { width: number; height: number };
  bitrate?: number;
  framerate?: number;
  audioSampleRate?: number;
  status: 'waiting' | 'converting' | 'paused' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  startTime?: Date;
  endTime?: Date;
  error?: string;
}

export interface VideoSource {
  id: string;
  name: string;
  url: string;
  category?: string;
  tags?: string[];
  resolution?: string;
  bitrate?: number;
  updatedAt: Date;
  status: 'normal' | 'invalid' | 'loading';
  enabled: boolean;
  lastPlayPosition?: number;
}

export interface VideoApp {
  id: string;
  name: string;
  icon?: string;
  description?: string;
  category: string;
  officialUrl?: string;
  videoSourceIds: string[];
  status: 'normal' | 'partial-invalid' | 'all-invalid';
  enabled: boolean;
  crawlerLogic?: string;
}

export interface WindowOptions {
  name: string;
  width?: number;
  height?: number;
  minWidth?: number;
  minHeight?: number;
  resizable?: boolean;
  frame?: boolean;
  transparent?: boolean;
  webPreferences?: {
    nodeIntegration?: boolean;
    contextIsolation?: boolean;
    preload?: string;
  };
}

export interface LogEntry {
  id: string;
  level: 'debug' | 'info' | 'warn' | 'error';
  module: string;
  message: string;
  timestamp: Date;
  meta?: any;
  error?: Error;
}

export interface UpdateInfo {
  version: string;
  releaseDate: string;
  releaseNotes: string;
  downloadUrl: string;
  sha256: string;
  size: number;
}

export interface AppSettings {
  paths: {
    tsDownloadFolder: string;
    videoOutputFolder: string;
    convertOutputFolder: string;
    logFolder: string;
  };
  general: {
    language: 'zh' | 'en';
    theme: 'light' | 'dark' | 'system';
    autoLaunch: boolean;
    notifications: {
      downloadComplete: boolean;
      convertComplete: boolean;
      parseSuccess: boolean;
    };
    autoUpdate: {
      enabled: boolean;
      frequency: 'daily' | 'weekly' | 'monthly';
      channel: 'stable' | 'beta';
    };
  };
  performance: {
    downloadThreads: number;
    cacheSize: number;
    hardwareAcceleration: boolean;
  };
  renderer: {
    autoReload: boolean;
    crashThreshold: number;
  };
}

