// 全局常量

export const APP_NAME = 'HLS Video Manager';
export const APP_VERSION = '1.0.0';

export const DEFAULT_SETTINGS: import('./types').AppSettings = {
  paths: {
    tsDownloadFolder: '',
    videoOutputFolder: '',
    convertOutputFolder: '',
    logFolder: ''
  },
  general: {
    language: 'zh',
    theme: 'system',
    autoLaunch: false,
    notifications: {
      downloadComplete: true,
      convertComplete: true,
      parseSuccess: true
    },
    autoUpdate: {
      enabled: true,
      frequency: 'weekly',
      channel: 'stable'
    }
  },
  performance: {
    downloadThreads: 4,
    cacheSize: 1024 * 1024 * 1024, // 1GB
    hardwareAcceleration: true
  },
  renderer: {
    autoReload: true,
    crashThreshold: 3
  }
};

export const SUPPORTED_VIDEO_FORMATS = [
  'mp4', 'mkv', 'avi', 'wmv', 'flv', 'ts', 'm3u8'
];

export const SUPPORTED_SUBTITLE_FORMATS = [
  'srt', 'ass', 'vtt'
];

export const IPC_CHANNELS = {
  // System
  SYSTEM_GET_INFO: 'system:get-info',
  SYSTEM_SET_AUTO_LAUNCH: 'system:set-auto-launch',
  SYSTEM_SEND_NOTIFICATION: 'system:send-notification',
  SYSTEM_SET_PROXY: 'system:set-proxy',
  
  // File
  FILE_SCAN_FOLDER: 'file:scan-folder',
  FILE_MERGE_FILES: 'file:merge-files',
  FILE_GET_INFO: 'file:get-info',
  FILE_DELETE: 'file:delete',
  FILE_RENAME: 'file:rename',
  
  // HLS Download
  HLS_PARSE_M3U8: 'hls:parse-m3u8',
  HLS_CREATE_DOWNLOAD: 'hls:create-download',
  HLS_OPERATE_TASK: 'hls:operate-task',
  HLS_GET_TASKS: 'hls:get-tasks',
  HLS_GET_PROGRESS: 'hls:get-progress',
  HLS_MERGE_TS: 'hls:merge-ts',
  
  // Video Convert
  CONVERT_CREATE_TASK: 'convert:create-task',
  CONVERT_OPERATE_TASK: 'convert:operate-task',
  CONVERT_GET_TASKS: 'convert:get-tasks',
  CONVERT_GET_PROGRESS: 'convert:get-progress',
  
  // Video Source
  VIDEO_SOURCE_ADD: 'video-source:add',
  VIDEO_SOURCE_UPDATE: 'video-source:update',
  VIDEO_SOURCE_DELETE: 'video-source:delete',
  VIDEO_SOURCE_GET_LIST: 'video-source:get-list',
  VIDEO_SOURCE_IMPORT: 'video-source:import',
  VIDEO_SOURCE_EXPORT: 'video-source:export',
  
  // Video App
  VIDEO_APP_ADD: 'video-app:add',
  VIDEO_APP_UPDATE: 'video-app:update',
  VIDEO_APP_DELETE: 'video-app:delete',
  VIDEO_APP_GET_LIST: 'video-app:get-list',
  VIDEO_APP_CHECK_SOURCES: 'video-app:check-sources',
  VIDEO_APP_SHOW_CONTEXT_MENU: 'video-app:show-context-menu',
  VIDEO_APP_TOGGLE_ENABLED: 'video-app:toggle-enabled',
  VIDEO_APP_START_CRAWL: 'video-app:start-crawl',
  
  // Settings
  SETTINGS_GET: 'settings:get',
  SETTINGS_UPDATE: 'settings:update',
  SETTINGS_SELECT_FOLDER: 'settings:select-folder',
  
  // Log
  LOG_GET_LIST: 'log:get-list',
  LOG_CLEAN: 'log:clean',
  LOG_EXPORT: 'log:export',
  
  // Update
  UPDATE_CHECK: 'update:check',
  UPDATE_DOWNLOAD: 'update:download',
  UPDATE_INSTALL: 'update:install',
  UPDATE_GET_LOG: 'update:get-log',
  
  // App Quit
  APP_QUIT_REQUEST: 'app:quit-request',
  APP_QUIT_CONFIRM: 'app:quit-confirm',
  APP_QUIT_CANCEL: 'app:quit-cancel'
};

