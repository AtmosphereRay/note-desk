import { createI18n } from 'vue-i18n';
import zh from './locales/zh';
import en from './locales/en';

// 从 localStorage 或默认值获取语言设置
const getInitialLocale = (): string => {
  try {
    // 尝试从主进程获取设置，如果不可用则使用默认值
    const stored = localStorage.getItem('app-language');
    return stored || 'zh';
  } catch {
    return 'zh';
  }
};

const i18n = createI18n({
  legacy: false,
  locale: getInitialLocale(),
  fallbackLocale: 'zh',
  messages: {
    zh,
    en
  }
});

// 监听语言变化（通过事件或直接调用）
export function setLocale(locale: 'zh' | 'en') {
  if (i18n.global.locale.value !== locale) {
    i18n.global.locale.value = locale;
    localStorage.setItem('app-language', locale);
    // 触发自定义事件，通知所有组件语言已变化
    window.dispatchEvent(new CustomEvent('locale-changed', { detail: { locale } }));
  }
}

export default i18n;

