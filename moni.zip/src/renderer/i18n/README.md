# i18n 使用指南

## 安装

i18n 已集成到项目中，使用 `vue-i18n`。

## 使用方法

### 1. 在组件中使用

```vue
<template>
  <div>
    <h1>{{ $t('common.title') }}</h1>
    <el-button>{{ $t('common.confirm') }}</el-button>
  </div>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n';

const { t } = useI18n();

// 在脚本中使用
const message = t('common.success');
</script>
```

### 2. 使用 composable

```typescript
import { useI18n } from '@/composables/useI18n';

const { t, locale } = useI18n();
```

### 3. 切换语言

语言切换会自动同步到设置：

```typescript
import { useSettingsStore } from '@/store/settings';

const settingsStore = useSettingsStore();
await settingsStore.updateSettings({
  general: {
    language: 'en' // 或 'zh'
  }
});
```

## 语言文件结构

- `locales/zh.ts` - 中文翻译
- `locales/en.ts` - 英文翻译

## 添加新翻译

1. 在 `locales/zh.ts` 和 `locales/en.ts` 中添加对应的键值
2. 在组件中使用 `$t('your.key')` 或 `t('your.key')`

## 翻译键命名规范

使用点号分隔的层级结构，例如：
- `common.confirm` - 通用确认按钮
- `login.title` - 登录页面标题
- `settings.general.language` - 设置中的语言选项

