<template>
  <el-config-provider :locale="locale">
    <router-view />
  </el-config-provider>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import { ElMessageBox } from 'element-plus';
import zhCn from 'element-plus/dist/locale/zh-cn.mjs';
import en from 'element-plus/dist/locale/en.mjs';
import { useSettingsStore } from './store/settings';
import { useTheme } from './composables/useTheme';

const { locale: i18nLocale, t } = useI18n();
const settingsStore = useSettingsStore();
const locale = computed(() => i18nLocale.value === 'zh' ? zhCn : en);

// 初始化主题
const { initTheme } = useTheme();
onMounted(() => {
  settingsStore.loadSettings().then(() => {
    initTheme();
  });
});

// 确保 Element Plus locale 响应语言变化
watch(
  () => i18nLocale.value,
  (newLocale) => {
    // locale computed 会自动更新，这里确保响应式
    // 强制触发 Element Plus locale 更新
    console.log('Language changed to:', newLocale);
  },
  { immediate: true }
);

// 监听自定义语言变化事件
onMounted(() => {
  window.addEventListener('locale-changed', () => {
    // 强制更新所有组件
    // Vue 的响应式系统应该自动处理，但这里确保 Element Plus 也更新
  });
});

// 处理退出确认
const handleQuitRequest = async () => {
  if (!window.electron) {
    return;
  }

  try {
    await ElMessageBox.confirm(
      t('app.quitConfirmMessage'),
      t('app.quitConfirmTitle'),
      {
        confirmButtonText: t('app.quitConfirm'),
        cancelButtonText: t('app.quitCancel'),
        type: 'warning',
        distinguishCancelAndClose: true,
        customClass: 'quit-confirm-dialog',
        center: true,
        closeOnClickModal: false,
        closeOnPressEscape: false
      }
    );

    // 用户确认退出
    if (window.electron) {
      await window.electron.app.confirmQuit();
    }
  } catch {
    // 用户取消退出
    if (window.electron) {
      await window.electron.app.cancelQuit();
    }
  }
};

// 监听退出请求事件
let removeQuitListener: (() => void) | null = null;

onMounted(() => {
  if ((window as any).electronEvents) {
    removeQuitListener = (window as any).electronEvents.onAppQuitRequest(handleQuitRequest);
  }
});

onUnmounted(() => {
  if (removeQuitListener) {
    removeQuitListener();
  }
});
</script>

<style>
/* 样式已在 theme.scss 中定义 */
</style>

