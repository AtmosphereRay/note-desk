<template>
  <el-dialog
    v-model="visible"
    :title="$t('appManagement.addApp')"
    width="800px"
    :close-on-click-modal="false"
    @close="handleClose"
  >
    <el-form :model="form" label-width="120px" :rules="rules" ref="formRef">
      <el-form-item :label="$t('appManagement.appName')" prop="name">
        <el-input
          v-model="form.name"
          :placeholder="$t('appManagement.appNamePlaceholder')"
        />
      </el-form-item>

      <el-form-item :label="$t('appManagement.icon')" prop="icon">
        <div class="icon-upload">
          <el-input
            v-model="form.icon"
            :placeholder="$t('appManagement.iconPlaceholder')"
            style="flex: 1"
          />
          <el-button @click="handleIconPreview" :disabled="!form.icon">
            {{ $t('appManagement.preview') }}
          </el-button>
        </div>
        <div v-if="iconPreview" class="icon-preview">
          <img :src="iconPreview" alt="Icon" />
        </div>
      </el-form-item>

      <el-form-item :label="$t('appManagement.enabled')">
        <el-switch v-model="form.enabled" />
      </el-form-item>

      <el-form-item :label="$t('appManagement.crawlerLogic')" prop="crawlerLogic">
        <el-input
          v-model="form.crawlerLogic"
          type="textarea"
          :rows="15"
          :placeholder="$t('appManagement.crawlerLogicPlaceholder')"
        />
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button @click="handleClose">{{ $t('common.cancel') }}</el-button>
      <el-button type="primary" @click="handleSubmit" :loading="loading">
        {{ $t('common.confirm') }}
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';
import type { FormInstance, FormRules } from 'element-plus';
import type { VideoApp } from '@shared/types';

const { t } = useI18n();

const props = defineProps<{
  modelValue: boolean;
}>();

const emit = defineEmits<{
  'update:modelValue': [value: boolean];
  'submit': [app: Omit<VideoApp, 'id' | 'status'>];
}>();

const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
});

const formRef = ref<FormInstance>();
const loading = ref(false);

const form = ref({
  name: '',
  icon: '',
  enabled: true,
  crawlerLogic: ''
});

const iconPreview = ref<string>('');

const rules: FormRules = {
  name: [
    { required: true, message: t('appManagement.appNameRequired'), trigger: 'blur' }
  ],
  crawlerLogic: [
    { required: true, message: t('appManagement.crawlerLogicRequired'), trigger: 'blur' }
  ]
};

watch(() => props.modelValue, (val) => {
  if (val) {
    form.value = {
      name: '',
      icon: '',
      enabled: true,
      crawlerLogic: ''
    };
    iconPreview.value = '';
    formRef.value?.clearValidate();
  }
});

const handleIconPreview = () => {
  if (form.value.icon) {
    iconPreview.value = form.value.icon;
  }
};

const handleClose = () => {
  visible.value = false;
};

const handleSubmit = async () => {
  if (!formRef.value) return;

  await formRef.value.validate((valid) => {
    if (valid) {
      loading.value = true;
      try {
        emit('submit', {
          name: form.value.name,
          icon: form.value.icon || undefined,
          enabled: form.value.enabled,
          crawlerLogic: form.value.crawlerLogic,
          category: '',
          videoSourceIds: []
        });
        handleClose();
      } catch (error) {
        ElMessage.error(t('appManagement.addFailed'));
      } finally {
        loading.value = false;
      }
    }
  });
};
</script>

<style scoped lang="scss">
.icon-upload {
  display: flex;
  gap: var(--spacing-sm);
  align-items: center;
}

.icon-preview {
  margin-top: var(--spacing-sm);
  padding: var(--spacing-md);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  background: var(--bg-tertiary);
  display: inline-block;

  img {
    max-width: 64px;
    max-height: 64px;
    display: block;
  }
}
</style>

