<template>
  <div class="app-logo">
    <img src="../assets/logo.svg" alt="HLS Video Manager" class="logo-image" />
    <span v-if="showText" class="logo-text">HLS Video Manager</span>
  </div>
</template>

<script setup lang="ts">
defineProps({
  showText: {
    type: Boolean,
    default: true
  }
});
</script>

<style scoped lang="scss">
.app-logo {
  display: flex;
  align-items: center;
  gap: 12px;
  
  .logo-image {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
  }
  
  .logo-text {
    font-size: 18px;
    font-weight: 700;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    white-space: nowrap;
  }
}
</style>


