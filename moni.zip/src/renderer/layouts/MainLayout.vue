<template>
  <el-container class="main-layout">
    <el-aside width="240px" class="sidebar">
      <div class="logo-container">
        <AppLogo />
      </div>
      <el-menu
        :default-active="activeMenu"
        router
        class="sidebar-menu"
        :collapse="false"
      >
        <el-menu-item index="/online-list">
          <el-icon><VideoPlay /></el-icon>
          <span>{{ $t('menu.onlineList') }}</span>
        </el-menu-item>
        <el-menu-item index="/app-management">
          <el-icon><Grid /></el-icon>
          <span>{{ $t('menu.appManagement') }}</span>
        </el-menu-item>
        <el-menu-item index="/download">
          <el-icon><Download /></el-icon>
          <span>{{ $t('menu.download') }}</span>
        </el-menu-item>
        <el-menu-item index="/local-player">
          <el-icon><Film /></el-icon>
          <span>{{ $t('menu.localPlayer') }}</span>
        </el-menu-item>
        <el-menu-item index="/network-collection">
          <el-icon><Link /></el-icon>
          <span>{{ $t('menu.networkCollection') }}</span>
        </el-menu-item>
        <el-menu-item index="/convert">
          <el-icon><Switch /></el-icon>
          <span>{{ $t('menu.convert') }}</span>
        </el-menu-item>
        <el-menu-item index="/tools">
          <el-icon><Tools /></el-icon>
          <span>{{ $t('menu.tools') }}</span>
        </el-menu-item>
        <el-menu-item index="/settings">
          <el-icon><Setting /></el-icon>
          <span>{{ $t('menu.settings') }}</span>
        </el-menu-item>
      </el-menu>
    </el-aside>
    <el-main class="main-content">
      <router-view />
    </el-main>
  </el-container>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import {
  VideoPlay,
  Grid,
  Download,
  Film,
  Link,
  Switch,
  Tools,
  Setting
} from '@element-plus/icons-vue';
import AppLogo from '../components/AppLogo.vue';

const route = useRoute();
const activeMenu = computed(() => route.path);
</script>

<style scoped lang="scss">
.main-layout {
  height: 100vh;
  width: 100%;
  background: var(--bg-secondary);
}

.sidebar {
  background: linear-gradient(180deg, #ffffff 0%, #f8f9fa 100%);
  border-right: 1px solid var(--border-color);
  box-shadow: var(--shadow-sm);
  
  .logo-container {
    padding: var(--spacing-lg);
    border-bottom: 1px solid var(--border-color);
    background: white;
  }
  
  .sidebar-menu {
    border-right: none;
    height: calc(100vh - 100px);
    padding: var(--spacing-sm);
    background: transparent;
  }
}

.main-content {
  padding: var(--spacing-xl);
  overflow-y: auto;
  background: var(--bg-secondary);
  min-height: 100vh;
}
</style>

