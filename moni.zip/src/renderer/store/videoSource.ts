import { defineStore } from 'pinia';
import { ref } from 'vue';
import type { VideoSource } from '@shared/types';

export const useVideoSourceStore = defineStore('videoSource', () => {
  const sources = ref<VideoSource[]>([]);

  async function loadSources() {
    if (window.electron) {
      sources.value = await window.electron.videoSource.getList();
    }
  }

  async function addSource(source: Omit<VideoSource, 'id' | 'updatedAt' | 'status'>) {
    if (window.electron) {
      await window.electron.videoSource.add(source);
      await loadSources();
    }
  }

  async function updateSource(id: string, updates: Partial<VideoSource>) {
    if (window.electron) {
      await window.electron.videoSource.update(id, updates);
      await loadSources();
    }
  }

  async function deleteSource(id: string) {
    if (window.electron) {
      await window.electron.videoSource.delete(id);
      await loadSources();
    }
  }

  return {
    sources,
    loadSources,
    addSource,
    updateSource,
    deleteSource
  };
});

