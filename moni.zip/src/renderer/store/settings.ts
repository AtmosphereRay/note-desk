import { defineStore } from 'pinia';
import { ref, watch } from 'vue';
import type { AppSettings } from '@shared/types';
import { setLocale } from '../i18n';

export const useSettingsStore = defineStore('settings', () => {
  const settings = ref<AppSettings>({
    paths: {
      tsDownloadFolder: '',
      videoOutputFolder: '',
      convertOutputFolder: '',
      logFolder: ''
    },
    general: {
      language: 'zh',
      theme: 'system',
      autoLaunch: false,
      notifications: {
        downloadComplete: true,
        convertComplete: true,
        parseSuccess: true
      },
      autoUpdate: {
        enabled: true,
        frequency: 'weekly',
        channel: 'stable'
      }
    },
    performance: {
      downloadThreads: 4,
      cacheSize: 1024 * 1024 * 1024,
      hardwareAcceleration: true
    },
    renderer: {
      autoReload: true,
      crashThreshold: 3
    }
  });

  async function loadSettings() {
    if (window.electron) {
      settings.value = await window.electron.settings.get();
    }
  }

  async function updateSettings(updates: Partial<AppSettings>) {
    if (window.electron) {
      await window.electron.settings.update(updates);
      await loadSettings();
    } else {
      // 如果没有 electron，直接更新本地设置
      Object.assign(settings.value, updates);
    }
  }

  // 监听语言设置变化
  watch(
    () => settings.value.general.language,
    (newLang) => {
      if (newLang === 'zh' || newLang === 'en') {
        setLocale(newLang);
      }
    }
  );

  // 监听主题设置变化
  watch(
    () => settings.value.general.theme,
    () => {
      // 主题变化由 useTheme composable 处理
    }
  );

  return {
    settings,
    loadSettings,
    updateSettings
  };
});

