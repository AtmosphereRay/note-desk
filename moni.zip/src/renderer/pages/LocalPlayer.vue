<template>
  <div class="local-player-page">
    <el-card>
      <template #header>
        <span>{{ $t('localPlayer.title') }}</span>
      </template>
      <div class="player-container">
        <video ref="videoPlayer" class="video-player" controls></video>
      </div>
      <div class="file-list">
        <el-button type="primary" @click="handleSelectFile">{{ $t('localPlayer.selectFile') }}</el-button>
        <el-button @click="handleScanFolder">{{ $t('localPlayer.scanFolder') }}</el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
const videoPlayer = ref<HTMLVideoElement>();

const handleSelectFile = () => {
  ElMessage.info(t('localPlayer.selectFileFeature'));
};

const handleScanFolder = () => {
  ElMessage.info(t('localPlayer.scanFolderFeature'));
};
</script>

<style scoped lang="scss">
.local-player-page {
  .player-container {
    width: 100%;
    margin-bottom: 20px;
    
    .video-player {
      width: 100%;
      max-height: 600px;
    }
  }
  
  .file-list {
    display: flex;
    gap: 10px;
  }
}
</style>

