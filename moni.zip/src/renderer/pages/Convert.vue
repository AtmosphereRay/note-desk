<template>
  <div class="convert-page">
    <el-card>
      <template #header>
        <span>{{ $t('convert.title') }}</span>
      </template>
      <el-table 
        :data="tasks" 
        style="width: 100%"
        :empty-text="$t('common.noData')"
      >
        <el-table-column prop="name" :label="$t('convert.taskName')" />
        <el-table-column prop="format" :label="$t('convert.targetFormat')" width="100" />
        <el-table-column prop="status" :label="$t('convert.status')" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column :label="$t('convert.progress')" width="200">
          <template #default="{ row }">
            <el-progress :percentage="row.progress" />
          </template>
        </el-table-column>
        <el-table-column :label="$t('convert.actions')" width="200">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleOperate(row)">{{ getOperateText(row.status) }}</el-button>
            <el-button link type="danger" @click="handleCancel(row)">{{ $t('convert.cancel') }}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
const tasks = ref<any[]>([]);

const getStatusType = (status: string) => {
  const map: Record<string, string> = {
    completed: 'success',
    converting: 'primary',
    paused: 'warning',
    failed: 'danger'
  };
  return map[status] || '';
};

const getStatusText = (status: string) => {
  const map: Record<string, string> = {
    waiting: t('convert.statusWaiting'),
    converting: t('convert.statusConverting'),
    paused: t('convert.statusPaused'),
    completed: t('convert.statusCompleted'),
    failed: t('convert.statusFailed'),
    cancelled: t('convert.statusCancelled')
  };
  return map[status] || status;
};

const getOperateText = (status: string) => {
  if (status === 'paused') return t('convert.resume');
  if (status === 'converting') return t('convert.pause');
  return t('convert.start');
};

const handleOperate = async (row: any) => {
  if (window.electron) {
    const action = row.status === 'paused' ? 'resume' : 'pause';
    await window.electron.videoConvert.operateTask(row.id, action);
    ElMessage.success(t('convert.operateSuccess'));
    loadTasks();
  }
};

const handleCancel = async (row: any) => {
  if (window.electron) {
    await window.electron.videoConvert.operateTask(row.id, 'cancel');
    ElMessage.success(t('convert.cancelled'));
    loadTasks();
  }
};

const loadTasks = async () => {
  if (window.electron) {
    tasks.value = await window.electron.videoConvert.getTasks();
  }
};

onMounted(() => {
  loadTasks();
  setInterval(loadTasks, 1000);
});
</script>

<style scoped lang="scss">
.convert-page {
  // 样式
}
</style>

