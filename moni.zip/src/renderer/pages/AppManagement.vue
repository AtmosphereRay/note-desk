<template>
  <div class="app-management-page">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>{{ $t('appManagement.title') }}</span>
          <el-button type="primary" :icon="Plus" @click="handleAdd">
            {{ $t('appManagement.addApp') }}
          </el-button>
        </div>
      </template>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-input
          v-model="searchKeyword"
          :placeholder="$t('appManagement.searchPlaceholder')"
          :prefix-icon="Search"
          clearable
          @input="handleSearch"
          style="width: 300px"
        />
      </div>

      <!-- 应用列表 -->
      <div v-if="paginatedApps.length > 0" class="app-grid">
        <div
          v-for="app in paginatedApps"
          :key="app.id"
          class="app-thumbnail"
          @click="handleAppClick(app)"
          @contextmenu.prevent="handleContextMenu($event, app)"
        >
          <div class="app-icon">
            <img v-if="app.icon" :src="app.icon" :alt="app.name" />
            <el-icon v-else :size="48"><Grid /></el-icon>
          </div>
          <div class="app-info">
            <div class="app-name">{{ app.name }}</div>
            <el-tag
              :type="app.enabled ? 'success' : 'info'"
              size="small"
              class="app-status"
            >
              {{ app.enabled ? $t('appManagement.enable') : $t('appManagement.disable') }}
            </el-tag>
          </div>
        </div>
      </div>

      <el-empty v-else :description="$t('appManagement.noApps')" />

      <!-- 分页 -->
      <div v-if="totalPages > 1" class="pagination">
        <el-pagination
          v-model:current-page="currentPage"
          :page-size="pageSize"
          :total="filteredApps.length"
          layout="prev, pager, next, jumper, total"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>

    <!-- 添加应用对话框 -->
    <AddAppDialog v-model="showAddDialog" @submit="handleAddSubmit" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import { Plus, Search, Grid } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';
import type { VideoApp } from '@shared/types';
import { getAllApps, updateApp } from '../utils/indexedDB';
import AddAppDialog from '../components/AddAppDialog.vue';

const { t } = useI18n();
const router = useRouter();

const apps = ref<VideoApp[]>([]);
const searchKeyword = ref('');
const currentPage = ref(1);
const pageSize = ref(12);
const showAddDialog = ref(false);

const filteredApps = computed(() => {
  if (!searchKeyword.value.trim()) {
    return apps.value;
  }
  return apps.value.filter(app =>
    app.name.toLowerCase().includes(searchKeyword.value.toLowerCase())
  );
});

const totalPages = computed(() => {
  return Math.ceil(filteredApps.value.length / pageSize.value);
});

const paginatedApps = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value;
  const end = start + pageSize.value;
  return filteredApps.value.slice(start, end);
});

const loadApps = async () => {
  try {
    // 优先从IndexedDB加载
    apps.value = await getAllApps();
    
    // 如果electron可用，尝试从主进程同步
    if (window.electron) {
      try {
        const mainProcessApps = await window.electron.videoApp.getList();
        // 合并数据（IndexedDB优先）
        const mainProcessAppMap = new Map(mainProcessApps.map(a => [a.id, a]));
        apps.value = apps.value.map(app => {
          const mainApp = mainProcessAppMap.get(app.id);
          return mainApp ? { ...app, ...mainApp } : app;
        });
      } catch (e) {
        console.warn('Failed to sync from main process:', e);
      }
    }
    
    // 如果当前页没有数据，回到第一页
    if (paginatedApps.value.length === 0 && currentPage.value > 1) {
      currentPage.value = 1;
    }
  } catch (error) {
    console.error('Failed to load apps:', error);
    ElMessage.error(t('appManagement.loadFailed'));
  }
};

const handleSearch = () => {
  currentPage.value = 1;
};

const handlePageChange = (page: number) => {
  currentPage.value = page;
};

const handleAdd = () => {
  showAddDialog.value = true;
};

const handleAddSubmit = async (appData: Omit<VideoApp, 'id' | 'status'>) => {
  try {
    // 优先使用IndexedDB（临时存储方案）
    const { addApp } = await import('../utils/indexedDB');
    await addApp(appData);
    
    // 如果electron可用，也同步到主进程
    if (window.electron) {
      try {
        await window.electron.videoApp.add(appData);
      } catch (e) {
        console.warn('Failed to sync to main process:', e);
      }
    }
    
    ElMessage.success(t('appManagement.addSuccess'));
    await loadApps();
  } catch (error) {
    console.error('Failed to add app:', error);
    ElMessage.error(t('appManagement.addFailed'));
  }
};

const handleAppClick = (app: VideoApp) => {
  router.push(`/app-management/${app.id}`);
};

const handleContextMenu = async (event: MouseEvent, app: VideoApp) => {
  if (window.electron) {
    try {
      await window.electron.videoApp.showContextMenu({
        appId: app.id,
        enabled: app.enabled,
        x: event.clientX,
        y: event.clientY
      });
      // 重新加载应用列表以反映状态变化
      await loadApps();
    } catch (error) {
      console.error('Failed to show context menu:', error);
    }
  }
};

// 处理应用启用状态变化
const handleEnabledChanged = async (event: any, data: { appId: string; enabled: boolean }) => {
  try {
    const { updateApp } = await import('../utils/indexedDB');
    await updateApp(data.appId, { enabled: data.enabled });
    await loadApps();
  } catch (error) {
    console.error('Failed to update app enabled state:', error);
    ElMessage.error(t('appManagement.updateFailed'));
  }
};

onMounted(() => {
  loadApps();
  
  // 监听主进程的事件
  if ((window as any).electronEvents) {
    // 监听应用启用状态变化
    const removeEnabledListener = (window as any).electronEvents.onVideoAppEnabledChanged(handleEnabledChanged);
    
    // 监听刷新列表事件
    const removeRefreshListener = (window as any).electronEvents.onVideoAppRefreshList(() => {
      syncFromMainProcess();
    });
    
    // 保存清理函数
    (window as any).__removeVideoAppListeners = () => {
      removeEnabledListener();
      removeRefreshListener();
    };
  }
});

onUnmounted(() => {
  if ((window as any).__removeVideoAppListeners) {
    (window as any).__removeVideoAppListeners();
  }
});

const syncFromMainProcess = async () => {
  if (window.electron) {
    try {
      const mainProcessApps = await window.electron.videoApp.getList();
      const { updateApp } = await import('../utils/indexedDB');
      
      // 同步主进程的数据到IndexedDB
      for (const app of mainProcessApps) {
        await updateApp(app.id, app);
      }
      
      await loadApps();
    } catch (error) {
      console.error('Failed to sync from main process:', error);
      // 即使同步失败，也刷新列表
      await loadApps();
    }
  } else {
    await loadApps();
  }
};
</script>

<style scoped lang="scss">
.app-management-page {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    span {
      font-size: 18px;
      font-weight: 700;
      color: var(--text-primary);
    }
  }

  .search-bar {
    margin-bottom: var(--spacing-lg);
  }

  .app-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: var(--spacing-lg);
    margin-bottom: var(--spacing-lg);
  }

  .app-thumbnail {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-lg);
    padding: var(--spacing-lg);
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    min-height: 180px;

    &:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-lg);
      border-color: var(--primary-color);
    }

    .app-icon {
      width: 80px;
      height: 80px;
      margin-bottom: var(--spacing-md);
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: var(--radius-md);
      background: var(--bg-tertiary);
      overflow: hidden;

      img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }

      .el-icon {
        color: var(--text-secondary);
      }
    }

    .app-info {
      width: 100%;

      .app-name {
        font-weight: 600;
        font-size: 14px;
        color: var(--text-primary);
        margin-bottom: var(--spacing-sm);
        word-break: break-word;
      }

      .app-status {
        margin-top: var(--spacing-xs);
      }
    }
  }

  .pagination {
    display: flex;
    justify-content: center;
    margin-top: var(--spacing-lg);
  }
}
</style>
