<template>
  <div class="login-container">
    <div class="login-wrapper">
      <div class="login-logo">
        <AppLogo :show-text="true" />
      </div>
      <el-card class="login-card" shadow="always">
        <template #header>
          <div class="card-header">
            <h2>{{ $t('login.title') }}</h2>
            <p class="subtitle">{{ $t('login.subtitle') }}</p>
          </div>
        </template>
      <el-form :model="form" label-width="0">
        <el-form-item>
          <el-input
            v-model="form.username"
            :placeholder="$t('login.username')"
            size="large"
            :prefix-icon="User"
          />
        </el-form-item>
        <el-form-item>
          <el-input
            v-model="form.password"
            type="password"
            :placeholder="$t('login.password')"
            size="large"
            :prefix-icon="Lock"
            @keyup.enter="handleLogin"
          />
        </el-form-item>
        <el-form-item>
          <el-button
            type="primary"
            size="large"
            style="width: 100%"
            @click="handleLogin"
          >
            {{ $t('login.login') }}
          </el-button>
        </el-form-item>
      </el-form>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { User, Lock } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';
import AppLogo from '../components/AppLogo.vue';

const router = useRouter();
const { t } = useI18n();
const form = ref({
  username: '',
  password: ''
});

const handleLogin = () => {
  // 暂时直接进入主页，不考虑请求
  ElMessage.success(t('login.loginSuccess'));
  router.push('/');
};
</script>

<style scoped lang="scss">
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: var(--primary-gradient);
  padding: var(--spacing-lg);
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
    animation: pulse 20s ease-in-out infinite;
  }
}

@keyframes pulse {
  0%, 100% {
    transform: scale(1);
    opacity: 0.5;
  }
  50% {
    transform: scale(1.1);
    opacity: 0.8;
  }
}

.login-wrapper {
  width: 100%;
  max-width: 440px;
  z-index: 1;
}

.login-logo {
  text-align: center;
  margin-bottom: var(--spacing-xl);
  
  :deep(.app-logo) {
    justify-content: center;
    
    .logo-text {
      color: white;
      -webkit-text-fill-color: white;
      font-size: 28px;
    }
  }
}

.login-card {
  width: 100%;
  border-radius: var(--radius-xl);
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.95);
  box-shadow: var(--shadow-xl);
  
  .card-header {
    text-align: center;
    padding: var(--spacing-md) 0;
    
    h2 {
      margin: 0 0 var(--spacing-xs) 0;
      color: var(--text-primary);
      font-size: 24px;
      font-weight: 700;
    }
    
    .subtitle {
      margin: 0;
      color: var(--text-secondary);
      font-size: 14px;
      font-weight: 400;
    }
  }
  
  :deep(.el-card__body) {
    padding: var(--spacing-xl);
  }
  
  :deep(.el-form-item) {
    margin-bottom: var(--spacing-lg);
  }
  
  :deep(.el-button) {
    height: 48px;
    font-size: 16px;
    font-weight: 600;
  }
}
</style>

