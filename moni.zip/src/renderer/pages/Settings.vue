<template>
  <div class="settings-page">
    <el-card>
      <template #header>
        <span>{{ $t('settings.title') }}</span>
      </template>
      <el-tabs v-model="activeTab">
        <el-tab-pane :label="$t('settings.paths')" name="paths">
          <el-form :model="settings.paths" label-width="200px">
            <el-form-item :label="$t('settings.tsDownloadFolder')">
              <div class="path-input-group">
                <el-input 
                  v-model="settingsStore.settings.paths.tsDownloadFolder" 
                  readonly
                  :placeholder="$t('settings.folderPlaceholder')"
                />
                <el-button 
                  type="primary" 
                  @click="handleSelectFolder('tsDownloadFolder')"
                >
                  {{ $t('settings.selectFolder') }}
                </el-button>
              </div>
            </el-form-item>
            <el-form-item :label="$t('settings.videoOutputFolder')">
              <div class="path-input-group">
                <el-input 
                  v-model="settingsStore.settings.paths.videoOutputFolder" 
                  readonly
                  :placeholder="$t('settings.folderPlaceholder')"
                />
                <el-button 
                  type="primary" 
                  @click="handleSelectFolder('videoOutputFolder')"
                >
                  {{ $t('settings.selectFolder') }}
                </el-button>
              </div>
            </el-form-item>
            <el-form-item :label="$t('settings.convertOutputFolder')">
              <div class="path-input-group">
                <el-input 
                  v-model="settingsStore.settings.paths.convertOutputFolder" 
                  readonly
                  :placeholder="$t('settings.folderPlaceholder')"
                />
                <el-button 
                  type="primary" 
                  @click="handleSelectFolder('convertOutputFolder')"
                >
                  {{ $t('settings.selectFolder') }}
                </el-button>
              </div>
            </el-form-item>
            <el-form-item :label="$t('settings.logFolder')">
              <div class="path-input-group">
                <el-input 
                  v-model="settingsStore.settings.paths.logFolder" 
                  readonly
                  :placeholder="$t('settings.folderPlaceholder')"
                />
                <el-button 
                  type="primary" 
                  @click="handleSelectFolder('logFolder')"
                >
                  {{ $t('settings.selectFolder') }}
                </el-button>
              </div>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane :label="$t('settings.general')" name="general">
          <el-form :model="settings.general" label-width="200px">
            <el-form-item :label="$t('settings.language')">
              <el-select v-model="settingsStore.settings.general.language" @change="handleLanguageChange">
                <el-option :label="$t('settings.languageZh')" value="zh" />
                <el-option :label="$t('settings.languageEn')" value="en" />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('settings.theme')">
              <div class="theme-selector">
                <el-radio-group v-model="settingsStore.settings.general.theme" @change="handleThemeChange" size="large">
                  <el-radio-button value="light">
                    <el-icon><Sunny /></el-icon>
                    <span>{{ $t('settings.light') }}</span>
                  </el-radio-button>
                  <el-radio-button value="dark">
                    <el-icon><Moon /></el-icon>
                    <span>{{ $t('settings.dark') }}</span>
                  </el-radio-button>
                  <el-radio-button value="system">
                    <el-icon><Monitor /></el-icon>
                    <span>{{ $t('settings.system') }}</span>
                  </el-radio-button>
                </el-radio-group>
                <div class="theme-preview">
                  <div class="preview-item" :class="{ active: settingsStore.settings.general.theme === 'light' }">
                    <div class="preview-light"></div>
                    <span>{{ $t('settings.light') }}</span>
                  </div>
                  <div class="preview-item" :class="{ active: settingsStore.settings.general.theme === 'dark' }">
                    <div class="preview-dark"></div>
                    <span>{{ $t('settings.dark') }}</span>
                  </div>
                  <div class="preview-item" :class="{ active: settingsStore.settings.general.theme === 'system' }">
                    <div class="preview-system"></div>
                    <span>{{ $t('settings.system') }}</span>
                  </div>
                </div>
              </div>
            </el-form-item>
            <el-form-item :label="$t('settings.autoLaunch')">
              <el-switch v-model="settingsStore.settings.general.autoLaunch" />
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane :label="$t('settings.performance')" name="performance">
          <el-form :model="settings.performance" label-width="200px">
            <el-form-item :label="$t('settings.downloadThreads')">
              <el-input-number v-model="settingsStore.settings.performance.downloadThreads" :min="1" :max="10" />
            </el-form-item>
            <el-form-item :label="$t('settings.hardwareAcceleration')">
              <el-switch v-model="settingsStore.settings.performance.hardwareAcceleration" />
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
      <div class="actions">
        <el-button type="primary" @click="handleSave">{{ $t('common.save') }}</el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { ElMessage } from 'element-plus';
import { Sunny, Moon, Monitor } from '@element-plus/icons-vue';
import { useSettingsStore } from '../store/settings';
import { useTheme } from '../composables/useTheme';
import { useI18n } from 'vue-i18n';
import { setLocale } from '../i18n';

const { t } = useI18n();
const settingsStore = useSettingsStore();
const { applyTheme } = useTheme();
const activeTab = ref('paths');
// 直接使用 store 的 settings，确保响应式
const settings = computed(() => settingsStore.settings);

const handleThemeChange = async (theme: 'light' | 'dark' | 'system') => {
  // 立即应用主题
  applyTheme(theme);
  // 保存设置
  await settingsStore.updateSettings({ general: { theme } });
  ElMessage.success(t('settings.themeChanged'));
};

const handleLanguageChange = async () => {
  // 立即更新 i18n locale，确保所有页面立即响应
  const newLang = settingsStore.settings.general.language;
  if (newLang === 'zh' || newLang === 'en') {
    setLocale(newLang);
  }
  // 然后保存到设置（store 中的 watch 会检测到变化，但我们已经手动调用了 setLocale）
  await settingsStore.updateSettings({ general: { language: newLang } });
};

const handleSelectFolder = async (pathKey: 'tsDownloadFolder' | 'videoOutputFolder' | 'convertOutputFolder' | 'logFolder') => {
  if (!window.electron) {
    ElMessage.error(t('settings.folderDialogError'));
    return;
  }

  try {
    // 获取当前路径作为默认路径
    const currentPath = settingsStore.settings.paths[pathKey];
    const selectedPath = await window.electron.settings.selectFolder(currentPath || undefined);
    
    if (selectedPath) {
      // 更新设置
      await settingsStore.updateSettings({
        paths: {
          ...settingsStore.settings.paths,
          [pathKey]: selectedPath
        }
      });
      ElMessage.success(t('settings.saveSuccess'));
    }
  } catch (error) {
    console.error('Failed to select folder:', error);
    ElMessage.error(t('settings.folderSelectFailed'));
  }
};

const handleSave = async () => {
  await settingsStore.updateSettings(settingsStore.settings);
  ElMessage.success(t('settings.saveSuccess'));
};

onMounted(() => {
  settingsStore.loadSettings();
});
</script>

<style scoped lang="scss">
.settings-page {
  :deep(.el-card) {
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-md);
  }
  
  :deep(.el-tabs) {
    .el-tabs__header {
      margin-bottom: var(--spacing-lg);
    }
    
    .el-tabs__item {
      font-weight: 500;
      font-size: 15px;
    }
  }
  
  :deep(.el-form) {
    .el-form-item {
      margin-bottom: var(--spacing-lg);
    }
    
    .el-form-item__label {
      font-weight: 600;
      color: var(--text-primary);
    }
  }
  
  .theme-selector {
    width: 100%;
    
    :deep(.el-radio-group) {
      display: flex;
      gap: var(--spacing-sm);
      width: 100%;
      
      .el-radio-button {
        flex: 1;
        
        .el-radio-button__inner {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: var(--spacing-xs);
          padding: var(--spacing-md);
          width: 100%;
          border-radius: var(--radius-md);
          transition: all 0.3s ease;
          
          .el-icon {
            font-size: 20px;
          }
        }
        
        &.is-active .el-radio-button__inner {
          background: var(--primary-gradient);
          border-color: transparent;
          color: white;
        }
      }
    }
    
    .theme-preview {
      display: flex;
      gap: var(--spacing-md);
      margin-top: var(--spacing-lg);
      padding: var(--spacing-md);
      background: var(--bg-tertiary);
      border-radius: var(--radius-md);
      
      .preview-item {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: var(--spacing-sm);
        padding: var(--spacing-md);
        border-radius: var(--radius-md);
        border: 2px solid transparent;
        transition: all 0.3s ease;
        cursor: pointer;
        
        &.active {
          border-color: var(--primary-color);
          background: rgba(102, 126, 234, 0.1);
        }
        
        .preview-light,
        .preview-dark,
        .preview-system {
          width: 60px;
          height: 40px;
          border-radius: var(--radius-sm);
          border: 2px solid var(--border-color);
        }
        
        .preview-light {
          background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        }
        
        .preview-dark {
          background: linear-gradient(135deg, #1a1d29 0%, #252836 100%);
        }
        
        .preview-system {
          background: linear-gradient(135deg, #ffffff 50%, #1a1d29 50%);
        }
        
        span {
          font-size: 12px;
          color: var(--text-secondary);
          font-weight: 500;
        }
        
        &.active span {
          color: var(--primary-color);
          font-weight: 600;
        }
      }
    }
  }
  
  .path-input-group {
    display: flex;
    gap: var(--spacing-sm);
    width: 100%;
    
    .el-input {
      flex: 1;
    }
    
    .el-button {
      flex-shrink: 0;
      min-width: 100px;
    }
  }
  
  .actions {
    margin-top: var(--spacing-xl);
    padding-top: var(--spacing-lg);
    border-top: 1px solid var(--border-color);
    text-align: right;
    
    .el-button {
      min-width: 120px;
      height: 44px;
      font-weight: 600;
    }
  }
}
</style>

