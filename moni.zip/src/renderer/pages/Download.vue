<template>
  <div class="download-page">
    <el-card>
      <template #header>
        <span>{{ $t('download.title') }}</span>
      </template>
      <el-table 
        :data="tasks" 
        style="width: 100%"
        :empty-text="$t('common.noData')"
      >
        <el-table-column prop="name" :label="$t('download.taskName')" />
        <el-table-column prop="status" :label="$t('download.status')" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ getStatusText(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column :label="$t('download.progress')" width="200">
          <template #default="{ row }">
            <el-progress :percentage="row.progress" />
          </template>
        </el-table-column>
        <el-table-column prop="speed" :label="$t('download.speed')" width="100" />
        <el-table-column :label="$t('download.actions')" width="200">
          <template #default="{ row }">
            <el-button link type="primary" @click="handleOperate(row)">{{ getOperateText(row.status) }}</el-button>
            <el-button link type="danger" @click="handleCancel(row)">{{ $t('download.cancel') }}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
const tasks = ref<any[]>([]);

const getStatusType = (status: string) => {
  const map: Record<string, string> = {
    completed: 'success',
    downloading: 'primary',
    paused: 'warning',
    failed: 'danger'
  };
  return map[status] || '';
};

const getStatusText = (status: string) => {
  const map: Record<string, string> = {
    pending: t('download.statusPending'),
    downloading: t('download.statusDownloading'),
    paused: t('download.statusPaused'),
    completed: t('download.statusCompleted'),
    failed: t('download.statusFailed'),
    cancelled: t('download.statusCancelled')
  };
  return map[status] || status;
};

const getOperateText = (status: string) => {
  if (status === 'paused') return t('download.resume');
  if (status === 'downloading') return t('download.pause');
  return t('download.start');
};

const handleOperate = async (row: any) => {
  if (window.electron) {
    const action = row.status === 'paused' ? 'resume' : 'pause';
    await window.electron.hlsDownload.operateTask(row.id, action);
    ElMessage.success(t('download.operateSuccess'));
    loadTasks();
  }
};

const handleCancel = async (row: any) => {
  if (window.electron) {
    await window.electron.hlsDownload.operateTask(row.id, 'cancel');
    ElMessage.success(t('download.cancelled'));
    loadTasks();
  }
};

const loadTasks = async () => {
  if (window.electron) {
    tasks.value = await window.electron.hlsDownload.getTasks();
  }
};

onMounted(() => {
  loadTasks();
  // 定时刷新进度
  setInterval(loadTasks, 1000);
});
</script>

<style scoped lang="scss">
.download-page {
  // 样式
}
</style>

