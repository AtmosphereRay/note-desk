<template>
  <div class="app-detail-page">
    <!-- 返回栏 -->
    <div class="back-bar">
      <el-button :icon="ArrowLeft" text @click="handleBack">
        {{ $t('appManagement.back') }}
      </el-button>
      <span class="back-title">{{ $t('appManagement.appDetail') }}</span>
    </div>

    <el-card v-if="app" class="detail-card">
      <el-form :model="form" label-width="120px" :rules="rules" ref="formRef">
        <el-form-item :label="$t('appManagement.appName')" prop="name">
          <el-input
            v-model="form.name"
            :placeholder="$t('appManagement.appNamePlaceholder')"
          />
        </el-form-item>

        <el-form-item :label="$t('appManagement.icon')" prop="icon">
          <div class="icon-upload">
            <el-input
              v-model="form.icon"
              :placeholder="$t('appManagement.iconPlaceholder')"
              style="flex: 1"
            />
            <el-button @click="handleIconPreview" :disabled="!form.icon">
              {{ $t('appManagement.preview') }}
            </el-button>
          </div>
          <div v-if="iconPreview" class="icon-preview">
            <img :src="iconPreview" alt="Icon" />
          </div>
        </el-form-item>

        <el-form-item :label="$t('appManagement.enabled')">
          <el-switch v-model="form.enabled" />
        </el-form-item>

        <el-form-item :label="$t('appManagement.crawlerLogic')" prop="crawlerLogic">
          <el-input
            v-model="form.crawlerLogic"
            type="textarea"
            :rows="15"
            :placeholder="$t('appManagement.crawlerLogicPlaceholder')"
          />
        </el-form-item>

        <!-- 其他字段（预留） -->
        <el-form-item label="创建时间" v-if="(app as any).createdAt">
          <el-input :value="formatDate((app as any).createdAt)" readonly />
        </el-form-item>

        <el-form-item label="更新时间" v-if="(app as any).updatedAt">
          <el-input :value="formatDate((app as any).updatedAt)" readonly />
        </el-form-item>
      </el-form>

      <div class="action-bar">
        <el-button type="primary" @click="handleUpdate" :loading="loading">
          {{ $t('appManagement.update') }}
        </el-button>
      </div>
    </el-card>

    <el-empty v-else :description="$t('appManagement.appNotFound')" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { ArrowLeft } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';
import type { FormInstance, FormRules } from 'element-plus';
import type { VideoApp } from '@shared/types';
import { getApp, updateApp } from '../utils/indexedDB';

const { t } = useI18n();
const route = useRoute();
const router = useRouter();

const app = ref<VideoApp | null>(null);
const formRef = ref<FormInstance>();
const loading = ref(false);
const iconPreview = ref<string>('');

const form = ref({
  name: '',
  icon: '',
  enabled: true,
  crawlerLogic: ''
});

const rules: FormRules = {
  name: [
    { required: true, message: t('appManagement.appNameRequired'), trigger: 'blur' }
  ],
  crawlerLogic: [
    { required: true, message: t('appManagement.crawlerLogicRequired'), trigger: 'blur' }
  ]
};

const loadApp = async () => {
  const appId = route.params.id as string;
  if (!appId) {
    ElMessage.error(t('appManagement.appNotFound'));
    router.back();
    return;
  }

  try {
    if (window.electron) {
      const apps = await window.electron.videoApp.getList();
      app.value = apps.find(a => a.id === appId) || null;
    } else {
      app.value = await getApp(appId);
    }

    if (!app.value) {
      ElMessage.error(t('appManagement.appNotFound'));
      router.back();
      return;
    }

    form.value = {
      name: app.value.name,
      icon: app.value.icon || '',
      enabled: app.value.enabled !== false,
      crawlerLogic: app.value.crawlerLogic || ''
    };

    if (form.value.icon) {
      iconPreview.value = form.value.icon;
    }
  } catch (error) {
    console.error('Failed to load app:', error);
    ElMessage.error(t('appManagement.loadFailed'));
    router.back();
  }
};

const handleIconPreview = () => {
  if (form.value.icon) {
    iconPreview.value = form.value.icon;
  }
};

const handleBack = () => {
  router.push('/app-management');
};

const handleUpdate = async () => {
  if (!formRef.value || !app.value) return;

  await formRef.value.validate(async (valid) => {
    if (valid) {
      loading.value = true;
      try {
        const updates = {
          name: form.value.name,
          icon: form.value.icon || undefined,
          enabled: form.value.enabled,
          crawlerLogic: form.value.crawlerLogic
        };

        // 优先更新IndexedDB
        await updateApp(app.value.id, updates);
        
        // 如果electron可用，也同步到主进程
        if (window.electron) {
          try {
            await window.electron.videoApp.update(app.value.id, updates);
          } catch (e) {
            console.warn('Failed to sync to main process:', e);
          }
        }

        ElMessage.success(t('appManagement.updateSuccess'));
        await loadApp();
      } catch (error) {
        console.error('Failed to update app:', error);
        ElMessage.error(t('appManagement.updateFailed'));
      } finally {
        loading.value = false;
      }
    }
  });
};

const formatDate = (date?: Date | string) => {
  if (!date) return '-';
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString('zh-CN');
};

onMounted(() => {
  loadApp();
});
</script>

<style scoped lang="scss">
.app-detail-page {
  .back-bar {
    display: flex;
    align-items: center;
    gap: var(--spacing-md);
    margin-bottom: var(--spacing-lg);
    padding: var(--spacing-md);
    background: var(--bg-primary);
    border-radius: var(--radius-md);
    border: 1px solid var(--border-color);

    .back-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary);
    }
  }

  .detail-card {
    .icon-upload {
      display: flex;
      gap: var(--spacing-sm);
      align-items: center;
    }

    .icon-preview {
      margin-top: var(--spacing-sm);
      padding: var(--spacing-md);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      background: var(--bg-tertiary);
      display: inline-block;

      img {
        max-width: 64px;
        max-height: 64px;
        display: block;
      }
    }

    .action-bar {
      display: flex;
      justify-content: flex-end;
      margin-top: var(--spacing-xl);
      padding-top: var(--spacing-lg);
      border-top: 1px solid var(--border-color);
    }
  }
}
</style>

