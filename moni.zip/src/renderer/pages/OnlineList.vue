<template>
  <div class="online-list-page">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>{{ $t('onlineList.title') }}</span>
          <el-button type="primary" :icon="Plus" @click="handleAdd">{{ $t('onlineList.addSource') }}</el-button>
        </div>
      </template>
      
      <div class="filter-bar">
        <el-input
          v-model="searchKeyword"
          :placeholder="$t('onlineList.searchPlaceholder')"
          style="width: 300px"
          clearable
          :prefix-icon="Search"
        />
        <el-select v-model="filterCategory" :placeholder="$t('onlineList.category')" clearable style="width: 150px">
          <el-option :label="$t('onlineList.all')" value="" />
        </el-select>
        <el-select v-model="filterStatus" :placeholder="$t('onlineList.status')" clearable style="width: 150px">
          <el-option :label="$t('onlineList.all')" value="" />
          <el-option :label="$t('onlineList.statusNormal')" value="normal" />
          <el-option :label="$t('onlineList.statusInvalid')" value="invalid" />
          <el-option :label="$t('onlineList.statusLoading')" value="loading" />
        </el-select>
      </div>

      <el-table 
        :data="filteredList" 
        style="width: 100%" 
        v-loading="loading"
        :empty-text="$t('common.noData')"
      >
        <el-table-column prop="name" :label="$t('onlineList.videoName')" width="200" />
        <el-table-column prop="url" :label="$t('onlineList.sourceUrl')" show-overflow-tooltip />
        <el-table-column prop="category" :label="$t('onlineList.category')" width="120" />
        <el-table-column prop="resolution" :label="$t('onlineList.resolution')" width="100" />
        <el-table-column prop="status" :label="$t('onlineList.status')" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column :label="$t('onlineList.actions')" width="200" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="handlePlay(row)">{{ $t('onlineList.play') }}</el-button>
            <el-button link type="primary" @click="handleDownload(row)">{{ $t('onlineList.download') }}</el-button>
            <el-button link type="danger" @click="handleDelete(row)">{{ $t('common.delete') }}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="addDialogVisible" :title="$t('onlineList.addDialogTitle')" width="500px">
      <el-form :model="addForm" label-width="100px">
        <el-form-item :label="$t('onlineList.nameLabel')">
          <el-input v-model="addForm.name" :placeholder="$t('onlineList.namePlaceholder')" />
        </el-form-item>
        <el-form-item :label="$t('onlineList.urlLabel')">
          <el-input v-model="addForm.url" :placeholder="$t('onlineList.urlPlaceholder')" />
        </el-form-item>
        <el-form-item :label="$t('onlineList.categoryLabel')">
          <el-input v-model="addForm.category" :placeholder="$t('onlineList.categoryPlaceholder')" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="addDialogVisible = false">{{ $t('common.cancel') }}</el-button>
        <el-button type="primary" @click="handleConfirmAdd">{{ $t('common.confirm') }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { Plus, Search } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { useI18n } from 'vue-i18n';
import { useVideoSourceStore } from '../store/videoSource';

const { t } = useI18n();

const videoSourceStore = useVideoSourceStore();
const loading = ref(false);
const searchKeyword = ref('');
const filterCategory = ref('');
const filterStatus = ref('');
const addDialogVisible = ref(false);
const addForm = ref({
  name: '',
  url: '',
  category: ''
});

const filteredList = computed(() => {
  let list = videoSourceStore.sources;
  
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase();
    list = list.filter(item => 
      item.name.toLowerCase().includes(keyword) || 
      item.url.toLowerCase().includes(keyword)
    );
  }
  
  if (filterCategory.value) {
    list = list.filter(item => item.category === filterCategory.value);
  }
  
  if (filterStatus.value) {
    list = list.filter(item => item.status === filterStatus.value);
  }
  
  return list;
});

const getStatusType = (status: string) => {
  const map: Record<string, string> = {
    normal: 'success',
    invalid: 'danger',
    loading: 'warning'
  };
  return map[status] || '';
};

const getStatusText = (status: string) => {
  const map: Record<string, string> = {
    normal: t('onlineList.statusNormal'),
    invalid: t('onlineList.statusInvalid'),
    loading: t('onlineList.statusLoading')
  };
  return map[status] || status;
};

const handleAdd = () => {
  addDialogVisible.value = true;
  addForm.value = { name: '', url: '', category: '' };
};

const handleConfirmAdd = async () => {
  if (!addForm.value.name || !addForm.value.url) {
    ElMessage.warning(t('onlineList.fillCompleteInfo'));
    return;
  }
  
  await videoSourceStore.addSource(addForm.value);
  addDialogVisible.value = false;
  ElMessage.success(t('onlineList.addSuccess'));
};

const handlePlay = (row: any) => {
  // TODO: 打开播放器
  ElMessage.info(t('onlineList.playFeature'));
};

const handleDownload = (row: any) => {
  // TODO: 添加到下载任务
  ElMessage.info(t('onlineList.downloadFeature'));
};

const handleDelete = async (row: any) => {
  try {
    await ElMessageBox.confirm(t('onlineList.deleteConfirm'), t('common.warning'), {
      type: 'warning'
    });
    await videoSourceStore.deleteSource(row.id);
    ElMessage.success(t('onlineList.deleteSuccess'));
  } catch {
    // 用户取消
  }
};

onMounted(() => {
  videoSourceStore.loadSources();
});
</script>

<style scoped lang="scss">
.online-list-page {
  :deep(.el-card) {
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-md);
    
    .el-card__header {
      background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
      border-bottom: 2px solid var(--border-color);
    }
  }
  
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    
    span {
      font-size: 18px;
      font-weight: 700;
      color: var(--text-primary);
    }
  }
  
  .filter-bar {
    display: flex;
    gap: var(--spacing-md);
    margin-bottom: var(--spacing-lg);
    padding: var(--spacing-md);
    background: var(--bg-tertiary);
    border-radius: var(--radius-md);
  }
  
  :deep(.el-table) {
    border-radius: var(--radius-md);
    overflow: hidden;
    
    .el-table__header {
      th {
        background: var(--bg-tertiary);
        font-weight: 600;
      }
    }
    
    .el-table__row {
      transition: all 0.2s ease;
      
      &:hover {
        background: var(--bg-tertiary);
        transform: scale(1.01);
      }
    }
  }
  
  :deep(.el-button) {
    border-radius: var(--radius-md);
    font-weight: 500;
  }
}
</style>

