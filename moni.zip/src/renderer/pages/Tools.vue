<template>
  <div class="tools-page">
    <el-card>
      <template #header>
        <span>{{ $t('tools.title') }}</span>
      </template>
      <el-row :gutter="20">
        <el-col :span="8">
          <el-card shadow="hover" class="tool-card">
            <template #header>{{ $t('tools.imageToBase64') }}</template>
            <el-form :model="base64Form" label-width="0">
              <el-form-item>
                <el-input v-model="base64Form.url" :placeholder="$t('tools.imageUrlPlaceholder')" />
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="handleConvertBase64">{{ $t('tools.convert') }}</el-button>
              </el-form-item>
            </el-form>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card shadow="hover" class="tool-card">
            <template #header>{{ $t('tools.videoInfo') }}</template>
            <el-button type="primary" @click="handleViewVideoInfo">{{ $t('tools.selectVideo') }}</el-button>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card shadow="hover" class="tool-card">
            <template #header>{{ $t('tools.mergeTs') }}</template>
            <el-button type="primary" @click="handleMergeTs">{{ $t('tools.selectTsFiles') }}</el-button>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
const base64Form = ref({
  url: ''
});

const handleConvertBase64 = () => {
  ElMessage.info(t('tools.convertFeature'));
};

const handleViewVideoInfo = () => {
  ElMessage.info(t('tools.videoInfoFeature'));
};

const handleMergeTs = () => {
  ElMessage.info(t('tools.mergeTsFeature'));
};
</script>

<style scoped lang="scss">
.tools-page {
  .tool-card {
    margin-bottom: 20px;
  }
}
</style>

