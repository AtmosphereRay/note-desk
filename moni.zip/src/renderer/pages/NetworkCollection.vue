<template>
  <div class="network-collection-page">
    <el-card>
      <template #header>
        <span>{{ $t('networkCollection.title') }}</span>
      </template>
      <el-form :model="form" label-width="100px">
        <el-form-item :label="$t('networkCollection.urlLabel')">
          <el-input v-model="form.url" :placeholder="$t('networkCollection.urlPlaceholder')" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleParse">{{ $t('networkCollection.parse') }}</el-button>
        </el-form-item>
      </el-form>
      <el-divider />
      <div v-if="parseResult" class="parse-result">
        <h3>{{ $t('networkCollection.parseResult') }}</h3>
        <el-descriptions :column="1" border>
          <el-descriptions-item :label="$t('networkCollection.videoTitle')">{{ parseResult.title }}</el-descriptions-item>
          <el-descriptions-item :label="$t('networkCollection.m3u8Url')">{{ parseResult.m3u8Url }}</el-descriptions-item>
        </el-descriptions>
        <div class="actions">
          <el-button type="primary" @click="handleAddToList">{{ $t('networkCollection.addToList') }}</el-button>
          <el-button type="success" @click="handleDownload">{{ $t('onlineList.download') }}</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { useI18n } from 'vue-i18n';

const { t } = useI18n();
const form = ref({
  url: ''
});

const parseResult = ref<any>(null);

const handleParse = () => {
  ElMessage.info(t('networkCollection.parseFeature'));
  // TODO: 实现解析逻辑
};

const handleAddToList = () => {
  ElMessage.info(t('networkCollection.addToListFeature'));
};

const handleDownload = () => {
  ElMessage.info(t('networkCollection.downloadFeature'));
};
</script>

<style scoped lang="scss">
.network-collection-page {
  .parse-result {
    margin-top: 20px;
    
    .actions {
      margin-top: 20px;
      display: flex;
      gap: 10px;
    }
  }
}
</style>

