import { useI18n as useVueI18n } from 'vue-i18n';

/**
 * 便捷的 i18n composable
 * 提供类型安全的翻译函数
 */
export function useI18n() {
  const { t, locale, availableLocales } = useVueI18n();
  
  return {
    t,
    locale,
    availableLocales,
    // 便捷方法
    $t: t
  };
}

