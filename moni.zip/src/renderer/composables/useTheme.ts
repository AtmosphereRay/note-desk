import { watch, computed } from 'vue';
import { useSettingsStore } from '../store/settings';

export function useTheme() {
  const settingsStore = useSettingsStore();

  // 获取系统主题偏好
  const getSystemTheme = (): 'light' | 'dark' => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  };

  // 应用主题
  const applyTheme = (theme: 'light' | 'dark' | 'system') => {
    const html = document.documentElement;
    const actualTheme = theme === 'system' ? getSystemTheme() : theme;
    
    // 移除所有主题类
    html.classList.remove('dark');
    html.removeAttribute('data-theme');
    
    if (actualTheme === 'dark') {
      html.classList.add('dark');
      html.setAttribute('data-theme', 'dark');
    } else {
      html.setAttribute('data-theme', 'light');
    }
    
    // 强制触发重绘
    html.style.colorScheme = actualTheme;
  };

  // 当前有效主题（计算属性）
  const currentTheme = computed(() => {
    const theme = settingsStore.settings.general.theme;
    return theme === 'system' ? getSystemTheme() : theme;
  });

  // 初始化主题
  const initTheme = () => {
    applyTheme(settingsStore.settings.general.theme);
    
    // 监听系统主题变化（当设置为跟随系统时）
    if (window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleSystemThemeChange = () => {
        if (settingsStore.settings.general.theme === 'system') {
          applyTheme('system');
        }
      };
      
      // 使用 addEventListener 替代 addListener（更现代）
      if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', handleSystemThemeChange);
      } else {
        // 兼容旧浏览器
        mediaQuery.addListener(handleSystemThemeChange);
      }
    }
  };

  // 监听设置中的主题变化
  watch(
    () => settingsStore.settings.general.theme,
    (newTheme) => {
      applyTheme(newTheme);
    },
    { immediate: false }
  );

  return {
    currentTheme,
    applyTheme,
    initTheme,
    getSystemTheme
  };
}


