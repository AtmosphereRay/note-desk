import { createRouter, createWebHashHistory } from 'vue-router';
import type { RouteRecordRaw } from 'vue-router';

const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('../pages/Login.vue')
  },
  {
    path: '/',
    component: () => import('../layouts/MainLayout.vue'),
    redirect: '/online-list',
    children: [
      {
        path: '/online-list',
        name: 'OnlineList',
        component: () => import('../pages/OnlineList.vue'),
        meta: { title: 'menu.onlineList' }
      },
      {
        path: '/app-management',
        name: 'AppManagement',
        component: () => import('../pages/AppManagement.vue'),
        meta: { title: 'menu.appManagement' }
      },
      {
        path: '/app-management/:id',
        name: 'AppDetail',
        component: () => import('../pages/AppDetail.vue'),
        meta: { title: 'appManagement.appDetail' }
      },
      {
        path: '/download',
        name: 'Download',
        component: () => import('../pages/Download.vue'),
        meta: { title: 'menu.download' }
      },
      {
        path: '/local-player',
        name: 'LocalPlayer',
        component: () => import('../pages/LocalPlayer.vue'),
        meta: { title: 'menu.localPlayer' }
      },
      {
        path: '/network-collection',
        name: 'NetworkCollection',
        component: () => import('../pages/NetworkCollection.vue'),
        meta: { title: 'menu.networkCollection' }
      },
      {
        path: '/convert',
        name: 'Convert',
        component: () => import('../pages/Convert.vue'),
        meta: { title: 'menu.convert' }
      },
      {
        path: '/tools',
        name: 'Tools',
        component: () => import('../pages/Tools.vue'),
        meta: { title: 'menu.tools' }
      },
      {
        path: '/settings',
        name: 'Settings',
        component: () => import('../pages/Settings.vue'),
        meta: { title: 'menu.settings' }
      }
    ]
  }
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

export default router;

