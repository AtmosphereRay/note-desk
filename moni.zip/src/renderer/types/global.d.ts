/// <reference types="vite/client" />

declare global {
  interface Window {
    electron: import('../../preload/types').ElectronApi;
  }
}

export {};

