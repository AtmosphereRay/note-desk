// IndexedDB 工具类
import type { VideoApp } from '@shared/types';

const DB_NAME = 'HLSVideoManager';
const DB_VERSION = 1;
const STORE_NAME = 'videoApps';

let db: IDBDatabase | null = null;

export async function initDB(): Promise<IDBDatabase> {
  if (db) {
    return db;
  }

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      reject(new Error('Failed to open IndexedDB'));
    };

    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const objectStore = database.createObjectStore(STORE_NAME, { keyPath: 'id' });
        objectStore.createIndex('name', 'name', { unique: false });
        objectStore.createIndex('enabled', 'enabled', { unique: false });
      }
    };
  });
}

export async function getAllApps(): Promise<VideoApp[]> {
  const database = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction([STORE_NAME], 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();

    request.onsuccess = () => {
      const apps = request.result.map((app: any) => ({
        ...app,
        enabled: app.enabled !== false,
        videoSourceIds: app.videoSourceIds || [],
        status: app.status || 'normal',
        category: app.category || ''
      }));
      resolve(apps);
    };

    request.onerror = () => {
      reject(new Error('Failed to get apps'));
    };
  });
}

export async function getApp(id: string): Promise<VideoApp | null> {
  const database = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction([STORE_NAME], 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(id);

    request.onsuccess = () => {
      const app = request.result;
      if (app) {
        resolve({
          ...app,
          enabled: app.enabled !== false,
          videoSourceIds: app.videoSourceIds || [],
          status: app.status || 'normal',
          category: app.category || ''
        });
      } else {
        resolve(null);
      }
    };

    request.onerror = () => {
      reject(new Error('Failed to get app'));
    };
  });
}

export async function addApp(app: Omit<VideoApp, 'id' | 'status'>): Promise<string> {
  const database = await initDB();
  const id = `app_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const newApp: VideoApp = {
    ...app,
    id,
    status: 'normal',
    enabled: app.enabled !== false,
    videoSourceIds: app.videoSourceIds || [],
    category: app.category || ''
  };

  return new Promise((resolve, reject) => {
    const transaction = database.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.add(newApp);

    request.onsuccess = () => {
      resolve(id);
    };

    request.onerror = () => {
      reject(new Error('Failed to add app'));
    };
  });
}

export async function updateApp(id: string, updates: Partial<VideoApp>): Promise<void> {
  const database = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const getRequest = store.get(id);

    getRequest.onsuccess = () => {
      const app = getRequest.result;
      if (!app) {
        reject(new Error('App not found'));
        return;
      }

      const updatedApp = { ...app, ...updates };
      const putRequest = store.put(updatedApp);

      putRequest.onsuccess = () => {
        resolve();
      };

      putRequest.onerror = () => {
        reject(new Error('Failed to update app'));
      };
    };

    getRequest.onerror = () => {
      reject(new Error('Failed to get app for update'));
    };
  });
}

export async function deleteApp(id: string): Promise<void> {
  const database = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(new Error('Failed to delete app'));
    };
  });
}

export async function searchApps(keyword: string): Promise<VideoApp[]> {
  const allApps = await getAllApps();
  if (!keyword.trim()) {
    return allApps;
  }

  const lowerKeyword = keyword.toLowerCase();
  return allApps.filter(app => 
    app.name.toLowerCase().includes(lowerKeyword) ||
    (app.description && app.description.toLowerCase().includes(lowerKeyword))
  );
}

