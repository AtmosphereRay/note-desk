# HLS Video Manager

基于 Electron 的 HLS 视频综合管理桌面应用

## 技术栈

- **框架**: Electron 28.0.0
- **语言**: TypeScript 5.3.3
- **前端**: Vue 3.4.3 + Element Plus 2.5.0 + Vue Router 4.2.5
- **播放器**: Video.js 8.6.1
- **打包**: electron-builder 24.9.1
- **自动更新**: electron-updater 6.1.7

## 项目结构

```
src/
├── main/                # 主进程代码
│   ├── classes/         # 核心管理类
│   ├── ipc/             # IPC 事件处理
│   ├── updater/         # 自动更新逻辑
│   ├── utils/           # 工具函数
│   └── index.ts         # 主进程入口
├── preload/             # IPC 桥接层
│   ├── api/             # API 定义
│   ├── index.ts         # preload 入口
│   └── types.ts         # API 类型定义
├── renderer/            # 渲染进程代码
│   ├── components/      # UI 组件
│   ├── pages/           # 页面模块
│   ├── ipc/             # IPC 调用封装
│   ├── store/           # 状态管理
│   ├── router/          # 路由配置
│   ├── utils/           # 工具函数
│   └── index.ts         # 渲染进程入口
└── shared/              # 共享资源
    ├── types/           # 全局类型定义
    └── constants.ts     # 全局常量
```

## 开发

### 安装依赖

```bash
npm install
```

### 开发模式

```bash
npm run dev
```

### 构建

```bash
npm run build
```

### 打包

```bash
# 所有平台
npm run dist

# Windows
npm run dist:win

# macOS
npm run dist:mac

# Linux
npm run dist:linux
```

## 功能模块

1. **视频在线列表** - HLS 视频源管理
2. **视频应用管理** - 应用分类与展示
3. **下载模块** - HLS 视频下载
4. **本地文件播放** - 本地视频播放器
5. **网络资源采集** - 网页视频源解析
6. **视频转换管理** - 视频格式转换
7. **工具库** - 辅助工具集合
8. **系统设置** - 应用配置管理

## 许可证

MIT

