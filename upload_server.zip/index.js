const express = require('express');
const https = require('https');
const fs = require('fs');
const multer = require('multer');
const { join } = require('path');
const { spawn, execSync, spawnSync } = require('child_process');
const path = require('path');
// 创建 Express 应用
const app = express();

// 设置静态资源目录
const PORT = 6443; // 使用默认的 HTTPS 端口 443
const STATIC_DIR = __dirname + '/public'; // 静态资源目录

app.use(express.static(STATIC_DIR));

// 配置 multer 以处理文件上传
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/') // 上传文件的目标目录
    },
    filename: function (req, file, cb) {
        // fs.existsSync(path.join(__dirname, './uploads/src.zip')) && fs.rmSync(path.join(__dirname, './uploads/src.zip'));
        cb(null, file.originalname);
        // 生成唯一的文件名
        // fs.existsSync(join(__dirname, 'uploads', file.originalname)) ? cb(null, Date.now() + '-' + file.originalname) : cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

app.get('/demo', (req, res) => {
    res.end(`
            document.querySelectorAll('*').forEach(el => {

        el.style.userSelect = 'text';
        el.oncopy = (e)=>{
            e.stopPropagation();

        }

        if(el.tagName === 'IFRAME'){
            console.log(el.onload);
            var iframeDocument = el.contentWindow.document || el.contentDocument;
            var insertScript = "
               <script>
                 window.onload =  ()=>{
    document.querySelectorAll('*').forEach(el => {

        el.style.userSelect = 'text';
        el.oncopy = (e)=>{
            e.stopPropagation();
            e.preventDefault();
            console.log(12312321,e,'iframe')
        }
        }
}

               </script>
            "
            el.onload = function() {
                console.log(123123,iframeDocument,iframeDocument.head)

            }
        }
    })
    `)
})

// 创建上传文件的路由
app.post('/upload', upload.single('file'), (req, res) => {

    res.setHeader('Access-Control-Allow-Origin', '*');
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }
    if (req.file.filename === 'src.zip') {
        // console.log('need unzip')
        unzipSrc();
    }

    console.log(req.file, 'deded')



    res.send(`File uploaded successfully. File name: ${req.file.filename}`);
});

app.get('*', (req, res) => {
    res.setHeader('Access-Allow-Origin', "*");
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 创建 HTTPS 服务器
const options = {
    key: fs.readFileSync('./cert/key.pem'), // 私钥路径
    cert: fs.readFileSync('./cert/ca.pem')  // 证书路径
};



app.listen(PORT, '0.0.0.0', () => {
    console.log(`HTTPS server is running on port ${PORT}`);
   // process.platform === 'linux' && startCallService();
});



function unzipSrc() {
    const name = path.join(__dirname, 'uploads', 'src.zip');
    console.log('move start!')

    const child = spawn('unzip', ['-u', '-o', name,], { shell: true });

    // console.log('unzip params', [name].join('ds'));
    child.addListener('close', code => {
        // fs.existsSync(path.join(__dirname, './uploads/src')) && fs.rmSync(path.join(__dirname, './uploads/src'));
        console.log('unzip finish!', code);
    })

    child.addListener('exit', code => {
        // fs.existsSync(path.join(__dirname, './uploads/src')) && fs.rmSync(path.join(__dirname, './uploads/src'));
        console.log('unzip exit!', code,);
        copyFolder()
    })

    child.addListener('error', msg => {
        console.log('unzip failed:', msg)
    })
}


function copyFolder(originZip = 'src') {
    const output = path.join(__dirname, 'src');
    const pasteOne = "/home/l/cf_project/webrtc_backend";
    const pasteTwo = "/home/l/webrtc-backend/fix2";
    const pasteThree = "/home/l/webrtc-backend/webrtc_backend";

    if (fs.existsSync(output)) {
        execSync([
            'mkdir', '-p', `"${pasteOne}"`,
            '&&', 'mkdir', '-p', `"${pasteTwo}"`,
            '&&', 'mkdir', '-p', `"${pasteThree}"`,
            '&&', 'cp', '-f', '-R', output, pasteOne,
            '&&', 'cp', '-f', '-R', output, pasteTwo,
            '&&', 'cp', '-f', '-R', output, pasteThree
        ].join(' '), { shell: true });

        fs.existsSync(output) && execSync(`rm -rf "${output}"`);

        fs.existsSync(path.join(__dirname, `./uploads/src.zip`)) && fs.rmSync(path.join(__dirname, `./uploads/src.zip`));
        console.log('move successfully!')
    } else {
        console.log('not exist', output)
    }
}

function startCallService() {
    const pasteOne = "/home/l/cf_project/webrtc_backend";
    const pasteTwo = "/home/l/webrtc-backend/fix2";
    const pasteThree = "/home/l/webrtc-backend/webrtc_backend";
    if (fs.existsSync(join(pasteOne, 'node_modules'))
        && fs.existsSync(join(pasteTwo, 'node_modules'))
        && fs.existsSync(join(pasteThree, 'node_modules'))
    ) {
        const p1 = spawn('npm', ['run', 'dev'], { cwd: pasteOne, shell: true  });
        const p2 = spawn('npm', ['run', 'dev'], { cwd: pasteTwo, shell: true });
        const p3 = spawn('npm', ['run', 'dev'], { cwd: pasteThree, shell: true });
        const open = [false, false, false] 

        p1.stdout.addListener('data', data => {
            // console.log(data.toString(), 'p1');
            const string = data.toString();
            if (string.includes('8787') && open[0] === false) {
                open[0] = true;
                console.info('p1 start success')

                // p1.stdin.write('[d] \n');
                // p1.stdin.write('d \n');
                // p1.stdin.write('b \n');
                // p1.stdin.write('[b] \n');
                // p1.stdin.end();
            }

            if (string.includes('alue in non-interactive context: no')) {
                console.warn('end edend ')
                p1.stdin.write('no \n');
                p1.stdin.end();
            }
        })

        p2.stdout.addListener('data', data => {
            // console.log(data.toString(), 'p2');
            const string = data.toString();
            if (string.includes('8989') && open[1] === false) {
                open[1] = true
                console.info('p1 start success', data.toString())
                p2.stdin.write('[d] \n');
                p2.stdin.end();
            }

            if (string.includes('alue in non-interactive context: no')) {
                console.warn('end edend', string)
                p2.stdin.write('\n');
                p2.stdin.end();
            }
        })

        p3.stdout.addListener('data', data => {
            // console.log(data.toString(), 'p3');
            const string = data.toString();
            if (string.includes('9000') && open[2] === false) {
                open[2] = true
                console.info('p3 start success', data.toString())
                p3.stdin.write('[d] \n');
                p3.stdin.write('d \n');
                p3.stdin.write('b \n');
                p3.stdin.write('[b] \n');



                p3.stdin.end();

            }

            if (string.includes('alue in non-interactive context: no')) {
                console.warn('end edend', string)
                p3.stdin.write('\n');
                p3.stdin.end();
            }
        })



        // 监听主进程的退出事件
        process.on('SIGINT', () => {
            console.log('收到 SIGINT 信号，关闭所有子进程...');

            p1.kill('SIGINT');
            p2.kill('SIGINT');
            p3.kill('SIGINT');
            process.exit(0)
        });

        process.on('SIGTERM', () => {
            console.log('收到 SIGTERM 信号，关闭所有子进程...');
            p1.kill('SIGINT');
            p2.kill('SIGINT');
            p3.kill('SIGINT');

        });

        process.on('exit', () => {
            console.log('主进程即将退出，关闭所有子进程...');
            p1.kill('SIGINT');
            p2.kill('SIGINT');
            p3.kill('SIGINT');
        });


        console.log('you can start up!');
    }
}


