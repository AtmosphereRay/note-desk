const spawn = require('child_process').spawn;

let exist = true;

const env = {
    ...process.env,
    TERM: 'xterm-256color' // 或者其他合适的值
};

const child = spawn('top', ['-b'], { env });
const pattern = /(?<pid>\S+)\s+(?<usr>\S+)\s+(?<pr>\S+)\s+(?<ni>\S+)\s+(?<vir>\S+)\s+(?<res>\S+)\s+(?<shr>\S+)\s+(?<s>\S+)\s+(?<cpu>\S+)\s+(?<mem>\S+)\s+(?<time>\S+)\s+(?<command>\S+)/;
const memoryPattern = /(?<total>[\d\.]+)\s+total,\s+(?<free>[\d\.]+)\s+free,\s+(?<used>[\d\.]+)\s+/

child.stdin.write('M');

child.stdout.setEncoding('utf-8');
child.stdout.on('data', (data) => {
    let _data = data.split('\n') || [];
    let headerLineIdx = -1;
    let memoryLineIdx = -1;
    _data.findIndex((line, idx) => {
        if (line.includes('MiB Mem')) {
            const q = memoryPattern.exec(line);

            if (q != null) {
                console.log(q.groups);
                memoryLineIdx = idx;
            }
        }
        if (line.includes('PID')) {
            headerLineIdx = idx + 1;
        }

    })
    if (headerLineIdx !== -1 && memoryLineIdx != -1) {
        _data.splice(0, headerLineIdx);
        const lastMemUseLineIdx = _data.findLastIndex(line => {
            // return !line.includes(' 0.0   0.0 ')
            const groups = pattern.exec(line)?.groups;
            // !!groups && console.log(groups, groups.cpu !== '0.0', groups.mem !== '0.0') || console.log(groups, line);
            return groups?.cpu !== '0.0' && groups?.mem !== '0.0'
        })
        // exist = false;
        lastMemUseLineIdx <= 15 && console.log('output data:', lastMemUseLineIdx, _data.splice(0, lastMemUseLineIdx))
    } else {
        data = _data = null;
    }

})


child.stderr.setEncoding('utf-8');
child.stderr.on('data', (data) => {
    console.log('error data:', data)
})


child.on('error', e => {
    console.log(e, 'error ')
})