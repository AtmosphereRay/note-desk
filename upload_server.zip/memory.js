const express = require('express');
const app = express();
const PORT = 3000;
const path = require('path')


const stack = []

app.get('/1', (req, res) => {
    stack.push('a'.repeat(1000))
    res.send(JSON.stringify({ ...process.memoryUsage(), len: stack.length }))
})

app.get('/2', (req, res) => {
    for (var i = 0; i < 1000; i++) {
        stack.push('a'.repeat(100000))
    }
    res.send(JSON.stringify({ ...process.memoryUsage(), len: stack.length }))
})

app.get('/3', (req, res) => {
    stack.splice(0);
    res.send(JSON.stringify({ ...process.memoryUsage(), len: stack.length }))
})

app.get('*', (req, res) => {
    res.setHeader('Access-Allow-Origin', "*");
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.listen(PORT, '0.0.0.0', () => {
    console.log(`HTTPS server is running on port ${PORT}`);
    // process.platform === 'linux' && startCallService();
});
