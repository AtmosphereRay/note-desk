#!/bin/bash

# 启动第一个Node.js项目
echo "Starting 1st Node.js project..."

# cd "/home/l/cf_project/webrtc_backend" && nohup  npm run dev   &

# 启动第二个Node.js项目
echo "Starting 2nd Node.js project..."
cd "/home/l/webrtc-backend/fix2" && nohup npm run dev  &


echo "Starting 3rd Node.js project..."
cd "/home/l/webrtc-backend/webrtc_backend" && nohup  npm run dev &

# 可选：等待所有子进程结束
wait

echo "All Node.js projects have been started."