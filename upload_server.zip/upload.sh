#!/bin/bash
cd "$(dirname "$0")"  
nohup npm run dev
