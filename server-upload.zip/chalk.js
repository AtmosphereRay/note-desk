const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

// 基本颜色
console.log(chalk.red('Hello world!'));  // 红色
console.log(chalk.green('Hello world!'));  // 绿色
console.log(chalk.green('Hello world green!'));  // 绿色

console.log('[32mHello world hahahah![39m')


fs.writeFileSync('green.txt', chalk.green('Hello world!'))

fs.writeFileSync('red.txt', chalk.red('Hello world!'))


// 背景色
console.log(chalk.bgYellow('Hello world!'));  // 黄色背景
fs.writeFileSync('yellowBg.txt', chalk.bgYellow('Hello world!'))


// 多个样式组合
console.log(chalk.blue.bgWhite.bold('Hello world!'));  // 蓝色文字、白色背景、加粗

// 字体修饰
console.log(chalk.underline('Underlined text'));  // 下划线

// 自定义颜色
console.log(chalk.hex('#FF5733')('Custom Hex Color'));  // 使用 hex 颜色

console.warn('warn-text');
console.info('info-text');
console.error('error-text');



