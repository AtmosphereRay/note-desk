const ansiStyles = require('ansi-styles');


const createStyler = (open, close, text = "") => {
    return `${open}${text}${close}`
};

function Chalk() {
    this.styles = Object.create(null);
    // for (const [styleName, style] of Object.entries(ansiStyles)) {
    // Object.defineProperty(this.styles, styleName, {
    //     get() {
    //         return (...args) => createStyler(style.open, style.close, ...args);
    //     }
    // })
    // }

    for (const [styleName, style] of Object.entries(ansiStyles)) {
        this.styles[styleName] = (template) => {
            return createStyler(style.open, style.close, template)
        }
    }
    return this.styles;
}

const chalk = new Chalk();


Object.keys(chalk).map(key => console.log(chalk[key](`${key} ===> demo`)))

module.exports = {
    instance: chalk,
    chalk: Chalk,
}





